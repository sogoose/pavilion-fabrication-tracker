@echo off
title Install LAMA Slicer
cd /d "%~dp0"
where py >nul 2>nul && (set "PY=py -3") || (set "PY=python")
%PY% --version >nul 2>nul || (echo Python 3 was not found. Install it from https://www.python.org and tick "Add Python to PATH". & pause & exit /b 1)
echo Installing the packages LAMA Slicer needs (numpy, shapely, trimesh, pywebview)...
%PY% -m pip install --upgrade -r requirements.txt || (echo Package installation failed - see the messages above. & pause & exit /b 1)
for /f "usebackq delims=" %%i in (`%PY% -c "import sys,os;print(os.path.join(os.path.dirname(sys.executable),'pythonw.exe'))"`) do set "PYW=%%i"
if not exist "%PYW%" (echo pythonw.exe was not found next to Python. & pause & exit /b 1)
echo Creating the LAMA Slicer shortcuts (desktop and Start menu)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=New-Object -ComObject WScript.Shell; foreach($d in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))){ $l=$s.CreateShortcut((Join-Path $d 'LAMA Slicer.lnk')); $l.TargetPath='%PYW%'; $l.Arguments='\"%~dp0lama_app.pyw\"'; $l.WorkingDirectory='%~dp0'; $l.IconLocation='%~dp0lama.ico'; $l.Description='LAMA Slicer - slicer for earth-based materials'; $l.Save() }"
echo.
echo Done. Start LAMA Slicer from the desktop or the Start menu. Starting it now...
start "" "%PYW%" "%~dp0lama_app.pyw"
timeout /t 3 >nul
