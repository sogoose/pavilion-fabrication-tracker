@echo off
title Build LAMA Slicer.exe
cd /d "%~dp0"
where py >nul 2>nul && (set "PY=py -3") || (set "PY=python")
rem Optional: makes a stand-alone program folder dist\LAMA Slicer\LAMA Slicer.exe (no Python needed on the target PC).
%PY% -m pip install --upgrade pyinstaller -r requirements.txt
%PY% -m PyInstaller --noconfirm --windowed --name "LAMA Slicer" --icon lama.ico ^
  --add-data "web;web" --add-data "toolpaths;toolpaths" --add-data "converters;converters" --add-data "lama.ico;." ^
  --hidden-import lama_server --hidden-import lama_engine --hidden-import numpy ^
  --collect-all shapely --collect-all trimesh --collect-all webview lama_app.pyw
echo.
echo Finished: dist\LAMA Slicer\LAMA Slicer.exe
pause
