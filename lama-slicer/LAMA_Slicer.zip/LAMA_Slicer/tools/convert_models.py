#!/usr/bin/env python3
"""Convert the Rhino machine files into the web models used by LAMA Slicer.

    python tools/convert_models.py wasp.3dm Station_Toolpath_Technoledge_Group_C.3dm
    python tools/convert_models.py --robodk Comau-Smart5-NJ-60-2-2.robot

Writes web/models/wasp.json, web/models/ur5_station.json and web/models/comau_nj60.json:
  {"parts": [{"name", "role", "pos": base64 float32 xyz, "idx": base64 uint32}], "meta": {...}}
Needs: numpy, rhino3dm (pip install rhino3dm). Uses the render meshes stored in the .3dm files;
Extrusions without a stored mesh (legs) are written as boxes.
"""
import base64
import json
import math
import os
import sys

import struct
import zlib

import numpy as np
try:
    import rhino3dm as r
except ImportError:                                   # only needed for the .3dm files
    r = None

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..', 'web', 'models')


def brep_mesh(g):
    if isinstance(g, r.Extrusion):
        g = g.ToBrep(False)
    V, F = [], []
    for i in range(len(g.Faces)):
        me = g.Faces[i].GetMesh(r.MeshType.Any)
        if me is None:
            continue
        b = len(V)
        V += [(me.Vertices[k].X, me.Vertices[k].Y, me.Vertices[k].Z) for k in range(len(me.Vertices))]
        for k in range(len(me.Faces)):
            q = me.Faces[k]
            F.append((b + q[0], b + q[1], b + q[2]))
            if q[2] != q[3]:
                F.append((b + q[0], b + q[2], b + q[3]))
    return np.array(V, float).reshape(-1, 3), np.array(F, np.uint32).reshape(-1, 3)


def box_mesh(bb):
    x0, y0, z0, x1, y1, z1 = bb
    V = np.array([[x, y, z] for z in (z0, z1) for y in (y0, y1) for x in (x0, x1)], float)
    F = np.array([[0, 2, 1], [1, 2, 3], [4, 5, 6], [5, 7, 6], [0, 1, 4], [1, 5, 4],
                  [2, 6, 3], [3, 6, 7], [0, 4, 2], [2, 4, 6], [1, 3, 5], [3, 7, 5]], np.uint32)
    return V, F


def bbox(g):
    b = g.GetBoundingBox()
    return (b.Min.X, b.Min.Y, b.Min.Z, b.Max.X, b.Max.Y, b.Max.Z)


def merge(meshes):
    V, F, n = [], [], 0
    for v, f in meshes:
        if len(f) == 0:
            continue
        V.append(v)
        F.append(f + n)
        n += len(v)
    return (np.concatenate(V), np.concatenate(F)) if V else (np.zeros((0, 3)), np.zeros((0, 3), np.uint32))


def part(name, role, mesh, M=None):
    V, F = mesh
    if M is not None:
        V = (np.c_[V, np.ones(len(V))] @ M.T)[:, :3]
    # weld identical vertices to keep the file small
    key = np.round(V, 2)
    uniq, inv = np.unique(key, axis=0, return_inverse=True)
    F = inv.reshape(-1)[F].astype(np.uint32)
    F = F[(F[:, 0] != F[:, 1]) & (F[:, 1] != F[:, 2]) & (F[:, 0] != F[:, 2])]
    return dict(name=name, role=role,
                pos=base64.b64encode(uniq.astype(np.float32).tobytes()).decode(),
                idx=base64.b64encode(F.astype(np.uint32).tobytes()).decode(),
                verts=len(uniq), tris=len(F))


def write(name, parts, meta):
    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, name)
    with open(path, 'w') as fh:
        json.dump(dict(parts=parts, meta=meta), fh, separators=(',', ':'))
    print('wrote', path, '%.0f kB' % (os.path.getsize(path) / 1024),
          ', '.join('%s %d' % (p['name'], p['tris']) for p in parts))


# ----------------------------------------------------------------------------- WASP 40100
def convert_wasp(path):
    m = r.File3dm.Read(path)        # the file says cm, the values are mm (bed radius 200)
    static, eff, arms = [], [], []
    TIP_Z = None
    for o in m.Objects:
        g = o.Geometry
        if not isinstance(g, (r.Brep, r.Extrusion)):
            continue
        bb = bbox(g)
        cx, cy = (bb[0] + bb[3]) / 2, (bb[1] + bb[4]) / 2
        w = max(bb[3] - bb[0], bb[4] - bb[1])
        mesh = brep_mesh(g)
        if 515 < bb[2] < 530 and 1040 < bb[5] < 1050 and (bb[3] - bb[0]) < 400 and w > 300:
            arms.append(mesh)                                  # diagonal arm (rebuilt at run time)
        elif math.hypot(cx, cy) < 80 and bb[5] < 830 and bb[2] > 440:
            eff.append((mesh, bb))                             # moves with the nozzle
            if w < 50 and bb[2] < 450:
                TIP_Z = bb[2]                                  # nozzle tip
        else:
            static.append(mesh)
    # arm joints: ends of each arm, de-duplicated (the file holds every arm twice)
    joints = {}
    for V, F in arms:
        lo = V[V[:, 2] < V[:, 2].min() + 3].mean(0)
        hi = V[V[:, 2] > V[:, 2].max() - 3].mean(0)
        k = (round(lo[0]), round(lo[1]))
        joints[k] = (lo, hi)
    tip = np.array([0.0, 0.0, TIP_Z])
    arm_meta = []
    for lo, hi in joints.values():
        arm_meta.append(dict(eff=(lo - tip).round(2).tolist(), car=hi[:2].round(2).tolist(),
                             L=round(float(np.linalg.norm(hi - lo)), 2), carZ=round(float(hi[2]), 2)))
    T = np.eye(4)
    T[:3, 3] = -tip                                            # effector parts relative to the tip
    effm = merge([e[0] for e in eff])
    # static: split into frame (dark) and the clay tank / bed (light) by size
    frame, light = [], []
    for V, F in static:
        x0, y0, z0 = V.min(0)
        x1, y1, z1 = V.max(0)
        if (z1 - z0) < 15 and (x1 - x0) > 300 and abs(z1) < 20:
            light.append((V, F))                               # bed plate
        elif math.hypot((x0 + x1) / 2, (y0 + y1) / 2) < 80 and z0 > 800:
            light.append((V, F))                               # clay tank on the top frame
        else:
            frame.append((V, F))
    parts = [part('frame', 'frame', merge(frame)), part('bed_tank', 'light', merge(light)),
             part('effector', 'effector', effm, T)]
    floor = min(float(V[:, 2].min()) for V, F in static)
    write('wasp.json', parts, dict(machine='WASP 40100', tip_home=tip.tolist(), arms=arm_meta,
                                   floor_z=round(floor, 2), bed_radius=200, build_height=1000))


# ----------------------------------------------------------------------------- UR5 station
def convert_station(path):
    m = r.File3dm.Read(path)
    lay = lambda o: m.Layers[o.Attributes.LayerIndex].FullPath
    table, legs, tool = [], [], []
    tcp = None
    for o in m.Objects:
        g, L = o.Geometry, lay(o)
        if L == 'Table::Table Top':
            table.append(brep_mesh(g))
        elif L == 'Table::Table Legs':
            legs.append(box_mesh(bbox(g)))
        elif L in ('Layer 01', 'Tool::Extruder') and isinstance(g, r.Brep):
            tool.append((L, brep_mesh(g), bbox(g)))
        elif L == 'Tool::Extruder' and isinstance(g, r.Point) and g.Location.X < -400:
            tcp = np.array([g.Location.X, g.Location.Y, g.Location.Z])       # nozzle tip
    # flange frame = centre of the 4 M6 bolt holes (Ø50 bolt circle) on the holder's base face
    holder = next(t for t in tool if t[0] == 'Layer 01' and t[2][2] > -1)
    holes = []
    for o in m.Objects:
        g = o.Geometry
        if lay(o) == 'Layer 01' and isinstance(g, r.Brep) and bbox(g)[2] > -1:
            for i in range(len(g.Edges)):
                e, d = g.Edges[i], g.Edges[i].Domain
                P = np.array([[e.PointAt(d.T0 + (d.T1 - d.T0) * k / 24).X, e.PointAt(d.T0 + (d.T1 - d.T0) * k / 24).Y,
                               e.PointAt(d.T0 + (d.T1 - d.T0) * k / 24).Z] for k in range(25)])
                if np.linalg.norm(P[0] - P[-1]) > 1e-3:
                    continue
                c = P[:-1].mean(0)
                rr = np.linalg.norm(P[:-1] - c, axis=1).mean()
                if 2.9 < rr < 3.4 and c[2] < 1.0:
                    holes.append(c)
    holes = np.array(holes)
    flange = holes.mean(0)
    pcd = 2 * np.linalg.norm(holes[:, :2] - flange[:2], axis=1).mean()
    print('bolt holes: %d, bolt circle Ø%.1f mm, flange centre %s' % (len(holes), pcd, flange.round(2)))
    # nozzle axis: from the extruder mount (Ø35 hole in the front plate) to the TCP point
    mount = np.array([-344.46, 0.76, -33.2])
    axis = tcp - mount
    axis /= np.linalg.norm(axis)
    ry = math.degrees(math.atan2(axis[0], axis[2]))                           # Rz(0) Ry(ry) Rz(0): z -> axis (y ~ 0)
    T = np.eye(4)
    T[:3, 3] = -flange
    tcp_f = tcp - flange
    names = {0: 'holder', 1: 'front', 2: 'tank'}
    parts = [part('table', 'table', merge(table)), part('legs', 'legs', merge(legs))]
    for L, mesh, bb in tool:
        nm = 'tank' if L == 'Tool::Extruder' else ('holder' if bb[2] > -1 else 'front')
        parts.append(part(nm, 'tool', mesh, T))
    meta = dict(machine='UR5 station', floor_z=-927.0, base_holes_radius=66.0,
                tcp=[round(float(tcp_f[0]), 2), round(float(tcp_f[1]), 2), round(float(tcp_f[2]), 2), 0.0, round(ry, 2), 0.0],
                mount=(mount - flange).round(2).tolist(), tank_front=[-48.6 - flange[0], -1.0, 65.0 - flange[2]],
                bolt_circle=round(float(pcd), 1))
    print('TCP in flange frame:', meta['tcp'])
    write('ur5_station.json', parts, meta)


# ----------------------------------------------------------------------------- RoboDK .robot
def read_robodk(path):
    """RoboDK robot file: Qt-compressed (4-byte size + zlib) little-endian stream.
    doubles: [21]=joints, [22]=bodies, [64..]=joint senses, [200 + 20*i]=DHM row (alpha, a, theta, d) of joint i
    (rad / mm), [2600..]/[2620..] lower/upper limits, [1900..] name as one double per character.
    From byte 32000: int64 bodies; per body: int64 sub-meshes; per sub-mesh: int64 triangles, RGBA float32,
    triangles x 3 x (xyz float32 + 2 bytes); per body two more int64 (0). Each body is in its own link frame."""
    raw = open(path, 'rb').read()
    x = zlib.decompress(raw[4:])
    d = np.frombuffer(x[:32000], dtype='<f8')
    nj = int(d[21])
    name = ''.join(chr(int(c)) for c in d[1900:1960] if 31 < c < 127)
    dhm = [[float(v) for v in d[200 + 20 * i:204 + 20 * i]] for i in range(nj)]
    sense = [int(v) for v in d[64:64 + nj]]
    lo = [float(v) for v in d[2600:2600 + nj]]
    hi = [float(v) for v in d[2620:2620 + nj]]
    hi2 = [float(v) for v in d[2660:2660 + nj]]
    hi = [max(a, b) for a, b in zip(hi, hi2)]
    o = 32000

    def q():
        nonlocal o
        v = struct.unpack('<q', x[o:o + 8])[0]
        o += 8
        return v
    bodies = []
    for b in range(q()):
        subs = []
        for s in range(q()):
            nt = q()
            col = struct.unpack('<4f', x[o:o + 16])
            o += 16
            rec = np.frombuffer(x[o:o + nt * 42], dtype=np.uint8).reshape(-1, 14)
            o += nt * 42
            subs.append((col, rec[:, :12].copy().view('<f4').reshape(-1, 3).astype(float)))
        q(), q()
        bodies.append(subs)
    assert o == len(x), 'unexpected .robot layout'
    return dict(name=name, dhm=dhm, sense=sense, lo=lo, hi=hi, bodies=bodies)


def convert_robodk(path, out_name='comau_nj60.json'):
    R = read_robodk(path)
    parts = []
    for b, subs in enumerate(R['bodies']):
        groups = {}
        for col, P in subs:
            r_, g_, b_ = col[:3]
            if abs(r_ - 0.671) < 0.01 and abs(b_ - 0.827) < 0.01:
                role = 'paint'                       # RoboDK body colour -> Comau red
            elif r_ > 0.7 and b_ < 0.1:
                role = 'label'
            elif r_ < 0.3:
                role = 'dark'
            else:
                role = 'grey'
            groups.setdefault(role, []).append(P)
        for role, Ps in groups.items():
            P = np.concatenate(Ps)
            F = np.arange(len(P), dtype=np.uint32).reshape(-1, 3)
            parts.append(part('b%d_%s' % (b, role), role, (P, F)))
    meta = dict(machine=R['name'], dhm=[[round(a, 6), round(b, 4), round(c, 6), round(d, 4)] for a, b, c, d in R['dhm']],
                sense=R['sense'], lo=R['lo'], hi=R['hi'], bodies=len(R['bodies']))
    print(R['name'], 'DHM', meta['dhm'], 'senses', meta['sense'])
    write(out_name, parts, meta)


if __name__ == '__main__':
    if sys.argv[1] == '--robodk':
        convert_robodk(sys.argv[2])
    else:
        convert_wasp(sys.argv[1])
        convert_station(sys.argv[2])
