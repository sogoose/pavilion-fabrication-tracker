#!/usr/bin/env python3
"""LAMA Slicer engine - runs the toolpath scripts (N1 / N2) and the G-code -> PDL converter.

Called by lama_server.py in a separate process:   python lama_engine.py job.json
The job file says what to do; the result is written to job['result_file'] as JSON.

The toolpath scripts in toolpaths/<N>/ are the Grasshopper scripts, unchanged. They are loaded
as modules, the settings are put into their globals (the same way Grasshopper inputs override
the SETTINGS block) and their own main() is called.
"""
import contextlib
import io
import json
import os
import re
import shutil
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLPATHS = os.path.join(HERE, 'toolpaths')
CONVERTERS = os.path.join(HERE, 'converters')
PDL_EDITABLE = {'print_speed_mm_s', 'travel_speed_mm_s', 'flow_rate_S', 'extrusion_factor', 'first_layer_z', 'approach_mm',
                'retract_mm', 'placement', 'tool', 'uframe', 'home', 'orient', 'config', 'approach_speed'}


def load_script(path, overrides=None):
    """Execute a script file as a module (main() does not run) and apply setting overrides."""
    with open(path, encoding='utf-8') as fh:
        src = fh.read()
    ns = {'__name__': 'lama_' + os.path.splitext(os.path.basename(path))[0], '__file__': path}
    exec(compile(src, path, 'exec'), ns)
    for k, v in (overrides or {}).items():
        ns[k] = v
    return ns


# ------------------------------------------------------------------------------------- slicing
def slice_one(tp_dir, mesh_path, work, pattern_over, slice_over, tag):
    """pattern + slice for one object -> toolpaths dict"""
    pat_file = os.path.join(work, tag + '_pattern.json')
    tp_file = os.path.join(work, tag + '_toolpaths.json')
    p = load_script(os.path.join(tp_dir, 'weave_pattern.py'), dict(pattern_over, OUTPUT_FILE=pat_file))
    p['main']([mesh_path])
    s = load_script(os.path.join(tp_dir, 'weave_slice.py'), slice_over)
    s['main']([mesh_path, pat_file, tp_file])
    with open(tp_file, encoding='utf-8') as fh:
        return json.load(fh)


def merge_toolpaths(parts):
    """several objects on one plate -> one toolpaths dict, layers merged by height (z)."""
    for i, tp in enumerate(parts):                 # remember the object of every path (preview can hide objects)
        for L in tp['layers']:
            for p in L['paths']:
                p['obj'] = i
    if len(parts) == 1:
        return parts[0]
    by_z = {}
    for tp in parts:
        for L in tp['layers']:
            key = round(L['z'], 3)
            if key not in by_z:
                by_z[key] = dict(z=L['z'], height=L['height'], paths=[])
            by_z[key]['paths'].extend(L['paths'])
    layers = [by_z[k] for k in sorted(by_z)]
    for i, L in enumerate(layers):
        L['index'] = i
    out = dict(parts[0])
    out['layers'] = layers
    out['part_center'] = [0.0, 0.0]
    out['part_height'] = max(tp['part_height'] for tp in parts)
    out['notes'] = [n for tp in parts for n in tp.get('notes', [])]
    return out


def job_slice(job):
    tp_dir = os.path.join(TOOLPATHS, job['toolpath'])
    work = job['work_dir']
    parts = []
    for i, mesh in enumerate(job['meshes']):
        print('--- object %d/%d: %s' % (i + 1, len(job['meshes']), mesh['name']))
        tp = slice_one(tp_dir, mesh['path'], work, job['pattern_over'], job['slice_over'], 'obj%d' % i)
        # the writer moves part_center onto the bed centre; the mesh is already in plate
        # coordinates, so the centre is put at the origin and the toolpaths stay where they are
        parts.append(tp)
    tp = merge_toolpaths(parts)
    tp['plate_coordinates'] = True
    tp['part_centers'] = [p['part_center'] for p in parts]
    out = os.path.join(work, 'toolpaths.json')
    with open(out, 'w', encoding='utf-8') as fh:
        json.dump(tp, fh, separators=(',', ':'))
    return dict(toolpaths_file=out, toolpaths=tp)


# ------------------------------------------------------------------------------------ G-code
ROBOT_NAME = {'wasp': 'Wasp', 'comau': 'Comau', 'ur5': 'UR5'}


def out_name(job, machine):
    """naming convention: [file name][robot].gcode  (A00 -> A00Comau.gcode, A00Comau.pdl)"""
    return job['name'] + ROBOT_NAME[machine]


def write_gcode(job, machine, final):
    """run the toolpath's own G-code writer (in the work folder) and move the file to `final`"""
    out_dir = job['work_dir']
    tp_dir = os.path.join(TOOLPATHS, job['toolpath'])
    with open(job['toolpaths_file'], encoding='utf-8') as fh:
        tp = json.load(fh)
    # keep plate coordinates: shift = BED_CENTER + PART_OFFSET - part_center = 0
    cx, cy = tp['part_center']
    over = dict(job['writer_over'], BED_CENTER_X=0.0, BED_CENTER_Y=0.0, PART_OFFSET_X=cx, PART_OFFSET_Y=cy,
                OUTPUT_FILE=out_dir, FILE_NAME='lama_out')
    w = load_script(os.path.join(tp_dir, 'weave_gcode.py'), over)
    flag = '--wasp' if machine == 'wasp' else '--comau'
    w['main']([job['toolpaths_file'], out_dir, 'lama_out', flag])
    tmp = os.path.join(out_dir, 'lama_out_Wasp.gcode' if machine == 'wasp' else 'lama_out_Comau.gcode')
    shutil.move(tmp, final)
    return final


def to_pdl(gcode_path, pdl, out_dir, name=None):
    """the user's gcode2pdl_arduino.py with the settings from the Comau panel"""
    g = load_script(os.path.join(CONVERTERS, 'gcode2pdl_arduino.py'))
    cfg = dict(g['DEFAULTS'])
    sfile = os.path.join(CONVERTERS, 'settings.json')
    if os.path.exists(sfile):
        with open(sfile, encoding='utf-8') as fh:
            cfg.update(json.load(fh))
    cfg.update({k: v for k, v in pdl.items() if k in PDL_EDITABLE})   # COM port, gear ratio, $FLY_DIST,
    cfg['name_suffix'] = ''                                             # $STRESS_PER stay as in settings.json; no name suffix
    st = {k: cfg[k] for k, _, _ in g['POPUP_FIELDS']}
    st['placement'] = cfg['placement']
    moves = g['trim'](g['parse'](gcode_path))
    if not moves:
        raise ValueError('No extruding moves found in ' + os.path.basename(gcode_path))
    pname = g['prog_name'](name or gcode_path, cfg)
    txt, info = g['build'](gcode_path, moves, st, cfg, pname)
    dst = os.path.join(out_dir, pname + '.pdl')
    with open(dst, 'w', newline='\r\n', encoding='utf-8') as fh:
        fh.write(txt)
    print('PDL: %s  (%d moves, %d paths, %d lines, S%d, Z %.1f-%.1f, est. %.0f min)' % (
        os.path.basename(dst), info['moves'], info['ons'], info['lines'], info['S'],
        info['zmin'] + info['dz'], info['zmax'] + info['dz'], g['estimate_min'](moves, st)))
    return dst


def job_export(job):
    machine = job['machine']               # wasp | comau | ur5
    os.makedirs(job['out_dir'], exist_ok=True)
    files = []
    gpath = os.path.join(job['out_dir'], out_name(job, machine) + '.gcode')
    if job.get('gcode_file'):              # imported custom G-code
        if os.path.abspath(job['gcode_file']) != os.path.abspath(gpath):
            shutil.copyfile(job['gcode_file'], gpath)
    else:                                  # UR5: the robot-neutral (Comau-format) G-code for now
        write_gcode(job, 'wasp' if machine == 'wasp' else 'comau', gpath)
    files.append(gpath)
    if machine == 'comau':
        files.append(to_pdl(gpath, job['pdl'], job['out_dir']))
    return dict(files=files)


def main(job_file=None):
    with open(job_file or sys.argv[1], encoding='utf-8') as fh:
        job = json.load(fh)
    buf = io.StringIO()
    res = dict(ok=False)
    try:
        with contextlib.redirect_stdout(buf):
            res.update({'slice': job_slice, 'export': job_export}[job['kind']](job))
        res['ok'] = True
    except SystemExit as e:
        res['error'] = 'Stopped: %s' % e
    except Exception as e:
        res['error'] = '%s: %s' % (type(e).__name__, e)
        res['trace'] = traceback.format_exc()
    res['log'] = [l for l in buf.getvalue().splitlines() if l.strip()]
    with open(job['result_file'], 'w', encoding='utf-8') as fh:
        json.dump(res, fh, separators=(',', ':'))


if __name__ == '__main__':
    main()
