"""LAMA Slicer - desktop application.

Opens LAMA Slicer in its own window (like Cura / Bambu Studio). No browser, no console:
start it with the "LAMA Slicer" shortcut (made by Install_LAMA_Slicer.bat) or double-click this file.
The interface runs on a local server inside this program; it is not reachable from the network.
"""
import os
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(sys.executable if getattr(sys, 'frozen', False) else __file__))
sys.path.insert(0, getattr(sys, '_MEIPASS', HERE))

# the packaged .exe also runs the slicing engine: LAMA Slicer.exe --engine job.json
if len(sys.argv) > 2 and sys.argv[1] == '--engine':
    import lama_engine
    lama_engine.main(sys.argv[2])
    sys.exit(0)


def error_box(text):
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, text, 'LAMA Slicer', 0x10)
    except Exception:
        print(text, file=sys.stderr)


class Api:
    """functions the interface can call: window.pywebview.api.<name>()
    Only public methods are exposed. pywebview walks every public attribute of this object,
    so the window is kept in _window (a public window attribute made start-up very slow and froze the app)."""

    def __init__(self):
        self._window = None

    def pick_folder(self, start=''):
        import webview
        kind = getattr(getattr(webview, 'FileDialog', None), 'FOLDER', None) or webview.FOLDER_DIALOG
        res = self._window.create_file_dialog(kind, directory=start if start and os.path.isdir(start) else '')
        return res[0] if res else None


def main():
    try:
        import webview
    except ImportError:
        error_box('LAMA Slicer needs the package "pywebview".\n\nRun Install_LAMA_Slicer.bat once, '
                  'or in a terminal:  pip install pywebview')
        return
    import lama_server
    srv, url = lama_server.start(port=0)
    api = Api()
    win = webview.create_window('LAMA Slicer', url, js_api=api, width=1600, height=960, min_size=(1100, 700),
                                background_color='#0C2340', text_select=True)
    api._window = win
    try:
        webview.settings['ALLOW_DOWNLOADS'] = True
    except Exception:
        pass
    icon = os.path.join(HERE, 'lama.ico')
    try:
        webview.start(icon=icon if os.path.exists(icon) else None, debug='--debug' in sys.argv)
    except TypeError:                                    # older pywebview without icon=
        webview.start(debug='--debug' in sys.argv)
    try:
        srv.shutdown()
    finally:
        os._exit(0)                                      # window closed: end at once, nothing left running


if __name__ == '__main__':
    try:
        main()
    except Exception:
        error_box('LAMA Slicer could not start:\n\n' + traceback.format_exc()[-1500:])
        os._exit(1)
