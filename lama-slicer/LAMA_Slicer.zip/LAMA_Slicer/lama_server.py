#!/usr/bin/env python3
"""LAMA Slicer - local server.

Desktop window: lama_app.pyw (LAMA Slicer shortcut). Browser mode: python lama_server.py

The interface lives in web/. Slicing and export run lama_engine.py in a separate process
so the toolpath scripts always start from a clean state.
"""
import base64
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

HERE = os.path.dirname(os.path.abspath(__file__))          # program files (read only when installed as .exe)
FROZEN = getattr(sys, 'frozen', False)
DATA = os.path.join(os.environ.get('LOCALAPPDATA') or os.path.expanduser('~'), 'LAMA Slicer') if FROZEN else HERE
WEB = os.path.join(HERE, 'web')
WORK = os.path.join(DATA, '.work')
SETTINGS_FILE = os.path.join(DATA, 'lama_settings.json')
DEFAULT_OUT = os.path.join(os.path.expanduser('~'), 'Documents', 'LAMA Slicer') if FROZEN else os.path.join(HERE, 'output')
NO_WINDOW = getattr(subprocess, 'CREATE_NO_WINDOW', 0)      # Windows: no console window for the engine
PORT = int(os.environ.get('LAMA_PORT', '8765'))
TOOLPATH_TYPES = ['N1', 'N2']

MIME = {'.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
        '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon'}

SLICES = {}          # slice id -> work folder with toolpaths.json
LOCK = threading.Lock()


# ------------------------------------------------------------------------------ defaults
def script_setting(path, name):
    """read `NAME = value` from a script's SETTINGS block"""
    with open(path, encoding='utf-8') as fh:
        m = re.search(r'^%s\s*=\s*([^#\n]+)' % re.escape(name), fh.read(), re.M)
    if not m:
        return None
    v = m.group(1).strip()
    try:
        return json.loads(v.replace("'", '"').replace('True', 'true').replace('False', 'false').replace('None', 'null'))
    except ValueError:
        return v


def toolpath_defaults(tp):
    d = os.path.join(HERE, 'toolpaths', tp)
    sl, gc = os.path.join(d, 'weave_slice.py'), os.path.join(d, 'weave_gcode.py')
    out = {n: script_setting(sl, n) for n in ('FIRST_LAYER_HEIGHT', 'LAYER_HEIGHT', 'FIRST_LAYER_WIDTH',
                                               'EXTERNAL_PERIMETER_WIDTH', 'PERIMETER_WIDTH', 'INFILL_WIDTH')}
    out.update({n: script_setting(gc, n) for n in ('INFILL_SPEED', 'TRAVEL_SPEED', 'COMAU_PRINT_FEED',
                                                    'COMAU_TRAVEL_FEED', 'FILAMENT_DENSITY')})
    with open(os.path.join(d, 'weave_pattern.py'), encoding='utf-8') as fh:
        doc = fh.read().split('"""')[1].strip().splitlines()
    out['description'] = doc[0] if doc else ''
    return out


def pdl_defaults():
    """the .bat converter's DEFAULTS, updated with its settings.json"""
    conv = os.path.join(HERE, 'converters')
    with open(os.path.join(conv, 'gcode2pdl_arduino.py'), encoding='utf-8') as fh:
        src = fh.read()
    block = src[src.index('DEFAULTS = {'):]
    block = block[:block.index('\n}\n') + 2]
    ns = {}
    exec(block, ns)
    cfg = dict(ns['DEFAULTS'])
    sfile = os.path.join(conv, 'settings.json')
    if os.path.exists(sfile):
        with open(sfile, encoding='utf-8') as fh:
            cfg.update(json.load(fh))
    return cfg


def load_saved():
    try:
        with open(SETTINGS_FILE, encoding='utf-8') as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


# ------------------------------------------------------------------------------ engine
def run_engine(job, timeout=1800):
    os.makedirs(job['work_dir'], exist_ok=True)
    jf = os.path.join(job['work_dir'], 'job_%s.json' % job['kind'])
    job['result_file'] = os.path.join(job['work_dir'], 'result_%s.json' % job['kind'])
    with open(jf, 'w', encoding='utf-8') as fh:
        json.dump(job, fh)
    env = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8')
    t0 = time.time()
    cmd = [sys.executable, '--engine', jf] if FROZEN else [sys.executable, os.path.join(HERE, 'lama_engine.py'), jf]
    p = subprocess.run(cmd, cwd=job['work_dir'], capture_output=True, text=True, timeout=timeout, env=env,
                       stdin=subprocess.DEVNULL, creationflags=NO_WINDOW)
    try:
        with open(job['result_file'], encoding='utf-8') as fh:
            res = json.load(fh)
    except (OSError, ValueError):
        res = dict(ok=False, error='The engine stopped without a result.', log=(p.stderr or '').splitlines()[-30:])
    res['seconds'] = round(time.time() - t0, 1)
    return res


def nozzle_widths(tp, nozzle):
    """all bead widths scale with the nozzle / bead width (default = the script's INFILL_WIDTH)"""
    d = toolpath_defaults(tp)
    k = float(nozzle) / float(d['INFILL_WIDTH'])
    return {n: round(float(d[n]) * k, 3) for n in ('FIRST_LAYER_WIDTH', 'EXTERNAL_PERIMETER_WIDTH',
                                                    'PERIMETER_WIDTH', 'INFILL_WIDTH')}


def api_slice(body):
    tp = body['toolpath']
    if tp not in TOOLPATH_TYPES:
        return dict(ok=False, error='Unknown toolpath type %s' % tp)
    if not body.get('objects'):
        return dict(ok=False, error='Add an object to the plate first.')
    sid = uuid.uuid4().hex[:10]
    work = os.path.join(WORK, sid)
    os.makedirs(work, exist_ok=True)
    meshes = []
    for i, o in enumerate(body['objects']):
        path = os.path.join(work, 'obj%d.stl' % i)
        with open(path, 'wb') as fh:
            fh.write(base64.b64decode(o['stl']))
        meshes.append(dict(name=o.get('name', 'object'), path=path))
    p = body['params']
    widths = nozzle_widths(tp, p['nozzle'])
    common = dict(MODEL_UNITS_TO_MM=1.0, FIRST_LAYER_HEIGHT=float(p['first_layer_height']))
    pattern_over = dict(common, EXTERNAL_PERIMETER_WIDTH=widths['EXTERNAL_PERIMETER_WIDTH'],
                        PERIMETER_WIDTH=widths['PERIMETER_WIDTH'], INFILL_WIDTH=widths['INFILL_WIDTH'])
    slice_over = dict(common, **widths, LAYER_HEIGHT=float(p['layer_height']))
    res = run_engine(dict(kind='slice', toolpath=tp, work_dir=work, meshes=meshes,
                          pattern_over=pattern_over, slice_over=slice_over))
    if res.get('ok'):
        with LOCK:
            SLICES[sid] = dict(work=work, toolpath=tp, file=res.pop('toolpaths_file'))
        res['slice_id'] = sid
        res['widths'] = widths
    return res


def safe_name(s):
    s = re.sub(r'[^A-Za-z0-9_\-]', '', (s or '').replace(' ', '_'))
    return s or 'part'


def api_export(body):
    machine = body['machine']
    p = body.get('params', {})
    out_dir = body.get('out_dir') or DEFAULT_OUT
    name = safe_name(body.get('name'))
    if body.get('gcode_text') is not None:           # imported G-code
        work = os.path.join(WORK, 'import_' + uuid.uuid4().hex[:8])
        os.makedirs(work, exist_ok=True)
        gfile = os.path.join(work, name + '.gcode')
        with open(gfile, 'w', encoding='utf-8', newline='\n') as fh:
            fh.write(body['gcode_text'])
        job = dict(kind='export', machine=machine, work_dir=work, out_dir=out_dir, name=name,
                   gcode_file=gfile, pdl=body.get('pdl', {}))
    else:
        with LOCK:
            sl = SLICES.get(body.get('slice_id'))
        if not sl:
            return dict(ok=False, error='Slice the plate first.')
        ps, ts = float(p.get('print_speed', 50)), float(p.get('travel_speed', 100))
        if machine == 'wasp':
            wo = dict(PERIMETER_SPEED=ps, EXTERNAL_PERIMETER_SPEED=ps, INFILL_SPEED=ps, TRAVEL_SPEED=ts)
        else:
            wo = dict(COMAU_PRINT_FEED=ps * 60.0, COMAU_TRAVEL_FEED=ts * 60.0)
        job = dict(kind='export', machine=machine, toolpath=sl['toolpath'], toolpaths_file=sl['file'],
                   work_dir=sl['work'], out_dir=out_dir, name=name, writer_over=wo, pdl=body.get('pdl', {}))
    res = run_engine(job)
    if res.get('ok'):
        res['out_dir'] = out_dir
        res['files'] = [dict(path=f, name=os.path.basename(f), size=os.path.getsize(f)) for f in res['files']]
    return res


def reveal(path):
    """show a file selected in the file manager"""
    if not os.path.exists(path):
        return dict(ok=False, error='Not found: ' + path)
    if sys.platform.startswith('win'):
        subprocess.Popen(['explorer', '/select,', os.path.normpath(path)])
    elif sys.platform == 'darwin':
        subprocess.Popen(['open', '-R', path])
    else:
        subprocess.Popen(['xdg-open', os.path.dirname(path)])
    return dict(ok=True)


def open_folder(path):
    if not os.path.isdir(path):
        return dict(ok=False, error='Folder not found: ' + path)
    if sys.platform.startswith('win'):
        os.startfile(path)                                   # noqa
    elif sys.platform == 'darwin':
        subprocess.Popen(['open', path])
    else:
        subprocess.Popen(['xdg-open', path])
    return dict(ok=True)


# ------------------------------------------------------------------------------ http
class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def send(self, code, data, ctype='application/json', extra=None):
        if not isinstance(data, (bytes, bytearray)):
            data = json.dumps(data).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        u = urlparse(self.path)
        if u.path == '/api/config':
            return self.send(200, dict(toolpaths={t: toolpath_defaults(t) for t in TOOLPATH_TYPES},
                                       pdl=pdl_defaults(), saved=load_saved(), out_dir=DEFAULT_OUT))
        if u.path == '/api/file':
            path = os.path.abspath(parse_qs(u.query).get('path', [''])[0])
            if not path.lower().endswith(('.gcode', '.pdl')) or not os.path.isfile(path):
                return self.send(404, dict(error='not found'))
            with open(path, 'rb') as fh:
                return self.send(200, fh.read(), 'application/octet-stream',
                                 {'Content-Disposition': 'attachment; filename="%s"' % os.path.basename(path)})
        rel = 'index.html' if u.path in ('/', '') else u.path.lstrip('/')
        path = os.path.abspath(os.path.join(WEB, rel))
        if not path.startswith(WEB) or not os.path.isfile(path):
            return self.send(404, b'not found', 'text/plain')
        with open(path, 'rb') as fh:
            self.send(200, fh.read(), MIME.get(os.path.splitext(path)[1], 'application/octet-stream'))

    def do_POST(self):
        n = int(self.headers.get('Content-Length', 0))
        try:
            body = json.loads(self.rfile.read(n) or b'{}')
            route = urlparse(self.path).path
            if route == '/api/slice':
                res = api_slice(body)
            elif route == '/api/export':
                res = api_export(body)
            elif route == '/api/settings':
                with open(SETTINGS_FILE, 'w', encoding='utf-8') as fh:
                    json.dump(body, fh, indent=2)
                res = dict(ok=True)
            elif route == '/api/open_folder':
                res = open_folder(body.get('path') or DEFAULT_OUT)
            elif route == '/api/reveal':
                res = reveal(body.get('path', ''))
            else:
                return self.send(404, dict(error='unknown route'))
            self.send(200, res)
        except Exception as e:                                  # report, keep the server alive
            self.send(200, dict(ok=False, error='%s: %s' % (type(e).__name__, e)))


def start(port=0):
    """start the server in a background thread -> (server, url); port 0 = any free port"""
    shutil.rmtree(WORK, ignore_errors=True)          # slices of the last session
    os.makedirs(WORK, exist_ok=True)
    os.makedirs(DEFAULT_OUT, exist_ok=True)
    srv = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, 'http://127.0.0.1:%d' % srv.server_address[1]


def main():
    shutil.rmtree(WORK, ignore_errors=True)          # slices of the last session
    os.makedirs(WORK, exist_ok=True)
    os.makedirs(DEFAULT_OUT, exist_ok=True)
    srv = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
    url = 'http://localhost:%d' % PORT
    print('LAMA Slicer running at %s  (close this window to stop)' % url)
    if '--no-browser' not in sys.argv:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    main()
