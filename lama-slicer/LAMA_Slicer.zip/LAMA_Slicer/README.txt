LAMA SLICER - slicer for earth-based materials
==============================================

INSTALL (once)
  1. Python 3.9+ from python.org ("Add Python to PATH" ticked).
  2. Double-click Install_LAMA_Slicer.bat: installs numpy, shapely, trimesh, pywebview,
     makes the "LAMA Slicer" shortcut on the desktop and in the Start menu, and starts it.

UPDATE TO A NEW VERSION
  Close LAMA Slicer, then replace the contents of this folder with the new version
  (same place, same folder name). The shortcut keeps working. Copy your "output" folder
  first if you keep exported files there. Running Install_LAMA_Slicer.bat again is safe.

UNINSTALL
  Run Uninstall_LAMA_Slicer.bat (removes the shortcuts and saved settings, optionally the
  Python packages), then delete this folder.

START
  The "LAMA Slicer" shortcut (or double-click lama_app.pyw). LAMA Slicer opens in its own
  window like Cura / Bambu Studio - no browser, no console window. Closing the window
  closes the program. (Run_in_browser.bat is a fallback that uses the web browser.)
  Optional: Build_exe_optional.bat makes a stand-alone "LAMA Slicer.exe" folder with
  PyInstaller (no Python needed on other PCs) - not tested yet, the shortcut is the way.

WORKFLOW
  1. Machine      WASP 40100 (.gcode), UR5 (.gcode), Comau NJ60-2.2 (.gcode + .pdl)
  2. Toolpath     N1 or N2 (your Grasshopper generators)
  3. Objects      Add / drop STL, OBJ or 3MF. The object's origin is the centre of its
                  lower face. Move it (drag, or type X, Y). Rotate it about X, Y and Z:
                  type an angle, use - / + (steps of 5, 15, 30, 45 or 90 deg) or the
                  preset angles; the Rotate gizmo snaps to the same step. After every
                  rotation the part is put back on the plate. Units: cm for Rhino cm models.
                  Several objects: the check box shows / hides an object (view and
                  preview); "Show only the selected object" isolates the selected one.
                  Undo / redo: Ctrl+Z / Ctrl+Y (or Ctrl+X, Ctrl+Shift+Z), or the arrows
                  in the toolbar - objects, placement and settings.
  4. Settings     Nozzle thickness, layer height, first layer height, print and
                  travel speed - stored separately for each machine.
                  Comau: the PDL settings of the gcode2pdl tool (flow S, factor, first
                  layer Z, approach / retract, $TOOL, $UFRAME, placement) and, under
                  Robot settings, home pose, nozzle orientation, configuration and
                  approach speed. COM port, gear ratio, $FLY_DIST and $STRESS_PER are
                  fixed: they come from converters\settings.json.
  5. Slice plate  Runs pattern -> slicer for every object (about 20 s per part).
                  Preview: drag the layer slider (or arrow keys) to show layers 1..n.
                  The nozzle of the robot follows the last point of the shown layer.
                  Playback (bottom bar, space bar): the machine follows the toolpath
                  with lifts and travels, the beads appear as they are printed;
                  1x - 1000x, drag the bar to scrub.
                  Machine: Solid / Transparent / Off - to see the print behind the robot.
  6. Export       [file name][robot].[extension], e.g. A00.obj ->
                  WASP  -> A00Wasp.gcode
                  Comau -> A00Comau.gcode + A00Comau.pdl  (PDL name: letters / digits only)
                  UR5   -> A00UR5.gcode (robot-neutral G-code for now)
                  Files go to the Output folder (default: LAMA_Slicer\output); "Show"
                  selects the file in Explorer.

  Import G-code   Load a G-code made elsewhere (e.g. AI-generated). It is previewed by
                  layer and exported for the selected machine (Comau: converted to PDL).
                  Its coordinates are taken as plate coordinates in mm.

WORLD COORDINATES
  Comau / UR5: the robot base is the world origin; the plate origin is $UFRAME (Comau)
  or "Plate origin" (UR5, default 0, -400, 6 on the station table). WASP: the plate
  origin is the bed centre.

MACHINE MODELS
  web\models\wasp.json and ur5_station.json are made from wasp.3dm and
  Station_Toolpath_Technoledge_Group_C.3dm by tools\convert_models.py
  (pip install rhino3dm, then: python tools\convert_models.py wasp.3dm station.3dm).
  UR5 tool: flange = centre of the 4 M6 holes (Ø50 bolt circle) of the holder,
  TCP = the point at the extruder tip -> -495.07, 0.01, -40.33, 0, -93.35, 0.
  Comau: web\models\comau_nj60.json from RoboDK's Comau-Smart5-NJ-60-2-2.robot
  (python tools\convert_models.py --robodk file.robot): link meshes, modified-DH
  kinematics and joint senses of the real robot, so the joint values are Comau J1..J6
  and the arm starts from the PDL home pose. The UR5 arm is a parametric model.
  Placement "keep" (default here) writes the part where it sits on the plate;
  "auto" / "center" behave as in the .bat tool.

FILES
  lama_server.py          local server + interface (web\)
  lama_engine.py          runs the scripts below in a separate process
  toolpaths\N1, N2        weave_pattern.py, weave_slice.py, weave_gcode.py - the scripts
                          from N1_generator.gh / N2_generator.gh, unchanged
  converters\             gcode2pdl_arduino.py + settings.json from the .bat tool
  lama_settings.json      last used settings (written automatically)

  To change a deeper toolpath setting, edit its SETTINGS block in toolpaths\N1 or N2;
  a new toolpath type = a new folder with the same three scripts (add its name to
  TOOLPATH_TYPES in lama_server.py and a button in web\index.html).

NOTES
  * N1 / N2 work on the module family they were written for; other shapes are refused
    with the script's message.
  * Playback follows the toolpath (= the points written to the .pdl) with the print /
    travel speed set here. It is not a controller simulation: Comau MOVEFLY blending,
    acceleration and the exact joint solution of the real robot are not modelled.
  * The UR5 arm is simplified (approximate shapes, real UR5 dimensions); the Comau is
    the RoboDK model. The "out of reach" badge uses these models.
  * The preview needs no internet (three.js is included in web\vendor).
