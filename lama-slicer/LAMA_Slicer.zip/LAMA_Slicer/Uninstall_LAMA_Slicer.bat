@echo off
title Uninstall LAMA Slicer
cd /d "%~dp0"
echo This removes the LAMA Slicer shortcuts (desktop and Start menu) and its saved settings.
echo Your exported files in the "output" folder are NOT touched.
echo.
choice /c YN /m "Uninstall LAMA Slicer"
if errorlevel 2 exit /b 0
taskkill /f /fi "WINDOWTITLE eq LAMA Slicer" >nul 2>nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "foreach($d in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))){ Remove-Item -LiteralPath (Join-Path $d 'LAMA Slicer.lnk') -ErrorAction SilentlyContinue }"
del /q "%~dp0lama_settings.json" >nul 2>nul
rd /s /q "%~dp0.work" >nul 2>nul
rd /s /q "%LOCALAPPDATA%\LAMA Slicer" >nul 2>nul
echo.
echo Shortcuts and settings removed.
echo.
choice /c YN /m "Also remove the Python packages pywebview, trimesh and shapely (keep them if other programs use them)"
if errorlevel 2 goto done
where py >nul 2>nul && (set "PY=py -3") || (set "PY=python")
%PY% -m pip uninstall -y pywebview trimesh shapely
:done
echo.
echo Last step: close this window and delete the LAMA_Slicer folder yourself
echo (copy the "output" folder somewhere first if you want to keep your exported files).
pause
