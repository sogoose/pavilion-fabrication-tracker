// LAMA Slicer - interface
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { TransformControls } from 'three/addons/controls/TransformControls.js';
import { STLLoader } from 'three/addons/loaders/STLLoader.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { ThreeMFLoader } from 'three/addons/loaders/3MFLoader.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { SerialArm, ModelArm, UR5_SPEC, DeltaPrinter, comauExtruder, stationExtruder, stationTable, loadModel, frameMatrix, zyz } from './robots.js';
import { parseGcode } from './gcode.js';

const $ = id => document.getElementById(id);
const D2R = Math.PI / 180;
const SETTINGS_VERSION = 2;
const MACHINES = { wasp: 'WASP 40100', ur5: 'UR5', comau: 'Comau NJ60-2.2' };
const TYPE_STYLE = {
  external: { color: 0x00a6d6, label: 'Outer wall' },
  perimeter: { color: 0x0c2340, label: 'Inner wall' },
  infill: { color: 0x9aa5b1, label: 'Weave (infill)' },
  fill: { color: 0x5c6670, label: 'Fill' },
  custom: { color: 0x00a6d6, label: 'Imported path' },
  other: { color: 0xc8102e, label: 'Other' },
};
// values of the .pdl conversion that stay as in converters/settings.json (not editable here)
const PDL_EDITABLE = ['print_speed_mm_s', 'travel_speed_mm_s', 'flow_rate_S', 'extrusion_factor', 'first_layer_z', 'approach_mm',
  'retract_mm', 'placement', 'tool', 'uframe', 'home', 'orient', 'config', 'approach_speed'];
const ROT_PRESETS = [0, 30, 45, 60, 90, 120, 135, 150, 180, 270];

// ------------------------------------------------------------------------------ state
let CONFIG = null;
const state = {
  v: SETTINGS_VERSION,
  machine: 'comau',
  toolpath: 'N2',
  params: {},          // per machine: nozzle, layer_height, first_layer_height, print_speed, travel_speed
  pdl: {},
  ur5: { plate: [0, -400, 6], tcp: [0, 0, 150, 0, 0, 0] },
  out_name: '',
  out_dir: '',
};
const objects = [];    // on the plate: {id, name, group, pivot, proxy, mesh, unit, rot:[x,y,z] deg, size, visible}
const registry = new Map();   // every object ever added (undo can bring deleted ones back)
let solo = false;             // show only the selected object
let machineView = 'solid';    // preview: solid | ghost | hidden
let selected = null;
let sliced = null;     // {kind:'slice'|'gcode', slice_id, layers, ...}
let stale = false;
let mode = 'prepare';
let objId = 0;
let rotAxis = 2;

// ------------------------------------------------------------------------------ scene
const vp = $('viewport');
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
vp.prepend(renderer.domElement);
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(36, 1, 5, 60000);
camera.up.set(0, 0, 1);
const orbit = new OrbitControls(camera, renderer.domElement);
orbit.enableDamping = true;
orbit.dampingFactor = 0.12;
orbit.screenSpacePanning = true;

scene.add(new THREE.HemisphereLight(0xffffff, 0x8a939c, 1.7));
const sun = new THREE.DirectionalLight(0xffffff, 1.5);
sun.position.set(2500, -1800, 4200);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
Object.assign(sun.shadow.camera, { left: -3000, right: 3000, top: 3000, bottom: -3000, near: 100, far: 12000 });
sun.shadow.bias = -0.0004;
scene.add(sun);
const fill = new THREE.DirectionalLight(0xe8f4ff, 0.55);
fill.position.set(-3000, 2500, 1500);
scene.add(fill);

const ground = new THREE.Group();
scene.add(ground);
const floor = new THREE.Mesh(new THREE.PlaneGeometry(14000, 14000), new THREE.ShadowMaterial({ opacity: 0.16 }));
floor.receiveShadow = true;
floor.position.z = -0.5;
ground.add(floor);
const grid = new THREE.GridHelper(8000, 80, 0x8f9aa5, 0xc4cbd2);
grid.rotation.x = Math.PI / 2;
grid.material.transparent = true;
grid.material.opacity = 0.6;
ground.add(grid);
const grid10 = new THREE.GridHelper(8000, 8, 0x6f7a85, 0x6f7a85);
grid10.rotation.x = Math.PI / 2;
grid10.position.z = 0.2;
ground.add(grid10);

const machineRoot = new THREE.Group();   // robot / printer / station
scene.add(machineRoot);
const plate = new THREE.Group();         // plate frame: origin = (0,0,0) of the print
plate.matrixAutoUpdate = false;
scene.add(plate);
const plateVisual = new THREE.Group();
plate.add(plateVisual);
const objectsRoot = new THREE.Group();
plate.add(objectsRoot);
const previewRoot = new THREE.Group();
plate.add(previewRoot);

const tcontrols = new TransformControls(camera, renderer.domElement);
tcontrols.setSpace('world');
tcontrols.setSize(0.9);
scene.add(tcontrols);
tcontrols.addEventListener('dragging-changed', e => {
  orbit.enabled = !e.value;
  if (!e.value && selected) { showObjectProps(); placementChanged(); }
});
tcontrols.addEventListener('objectChange', () => {
  if (!selected) return;
  if (tcontrols.mode === 'translate') {
    selected.group.position.z = 0;
  } else {
    const e = new THREE.Euler().setFromQuaternion(selected.proxy.quaternion, 'ZYX');
    selected.rot = [e.x, e.y, e.z].map(v => Math.round(v / D2R * 100) / 100);
    applyRotation(selected, false);
  }
  showObjectProps();
});

let machine = null;   // {kind, obj, seeds}
let buildToken = 0;
async function buildMachine() {
  const token = ++buildToken;
  const m = state.machine;
  const model = await loadModel({ wasp: 'wasp', ur5: 'ur5_station', comau: 'comau_nj60' }[m]);
  if (token !== buildToken) return;
  machineRoot.clear();
  plateVisual.clear();
  let floorZ = 0;
  if (m === 'wasp') {
    machine = { kind: 'delta', obj: new DeltaPrinter(model) };
    machineRoot.add(machine.obj.root);
    plate.matrix.identity();
    floorZ = model.meta.floor_z;
  } else {
    let arm;
    if (m === 'comau') {                // RoboDK model, joints = Comau J1..J6, IK starts from the PDL home pose
      arm = new ModelArm(model);
      arm.setTool(vec(state.pdl.tool, 6), comauExtruder);
      const home = vec(state.pdl.home, 6);
      arm.setQ(home.map(v => v * D2R));
      machine = { kind: 'arm', obj: arm, seeds: [home] };
    } else {
      arm = new SerialArm(UR5_SPEC);
      arm.setTool(vec(state.ur5.tcp, 6), stationExtruder(model));
      machine = { kind: 'arm', obj: arm, seeds: UR5_SPEC.seeds };
    }
    machineRoot.add(arm.root);
    const fr = m === 'comau' ? vec(state.pdl.uframe, 6) : [...vec(state.ur5.plate, 3), 0, 0, 0];
    plate.matrix.copy(frameMatrix(fr));
    if (m === 'ur5') {
      machineRoot.add(stationTable(model));
      floorZ = model.meta.floor_z;
      const board = new THREE.Mesh(new THREE.BoxGeometry(400, 400, 6), new THREE.MeshStandardMaterial({ color: 0xb8936a, roughness: 0.9 }));
      board.position.z = -3; board.receiveShadow = true;
      plateVisual.add(board);
    } else {
      const size = 600;                 // print board
      const board = new THREE.Mesh(new THREE.BoxGeometry(size, size, 18), new THREE.MeshStandardMaterial({ color: 0xd9c4a0, roughness: 0.85 }));
      board.position.z = -9.5; board.receiveShadow = true;
      plateVisual.add(board);
      const h = fr[2] - 18;
      if (h > 5) for (const [sx, sy] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(16, 20, h, 12), new THREE.MeshStandardMaterial({ color: 0x4a5058 }));
        leg.rotation.x = Math.PI / 2; leg.position.set(sx * (size / 2 - 50), sy * (size / 2 - 50), -18 - h / 2);
        plateVisual.add(leg);
      }
    }
  }
  ground.position.z = floorZ;
  plate.updateMatrixWorld(true);
  const axes = new THREE.AxesHelper(140);
  axes.material.depthTest = false;
  axes.renderOrder = 5;
  plateVisual.add(axes);
  machineRoot.traverse(o => { if (o.isMesh) o.castShadow = true; });
  applyMachineView();
  objects.forEach(updateSize);
  checkBounds();
  if (anim.keys) {                       // other machine = other speeds: same point of the print, new timeline
    const f = anim.total ? anim.t / anim.total : 0;
    buildTimeline();
    anim.t = f * anim.total;
  }
  if (mode === 'preview' && sliced) { if (anim.t > 0) animRender(); else setPreviewLayer(+$('layerSlider').value); }
  else poseMachine();
}

function applyMachineView() {
  const v = mode === 'preview' && sliced ? machineView : 'solid';
  machineRoot.visible = v !== 'hidden';
  machineRoot.traverse(o => {
    if (!o.isMesh) return;
    const mats = Array.isArray(o.material) ? o.material : [o.material];
    for (const mt of mats) {
      if (mt.userData.op === undefined) mt.userData.op = [mt.transparent, mt.opacity, mt.depthWrite];
      const [t, op, dw] = mt.userData.op;
      mt.transparent = v === 'ghost' ? true : t;
      mt.opacity = v === 'ghost' ? 0.14 : op;
      mt.depthWrite = v === 'ghost' ? false : dw;
      mt.needsUpdate = true;
    }
    o.castShadow = v === 'solid';
  });
}

function poseMachine(pt) {
  if (!machine) return;
  // pt: nozzle point in plate coordinates (preview / playback) or hover above the plate (prepare)
  if (!pt) {
    let h = 0;
    for (const o of objects) h = Math.max(h, o.size[2]);
    pt = new THREE.Vector3(0, 0, h + (state.machine === 'wasp' ? 120 : 150));
  }
  let res;
  if (machine.kind === 'delta') res = machine.obj.place(pt);
  else {
    const T = plate.matrix.clone().multiply(new THREE.Matrix4().makeTranslation(pt.x, pt.y, pt.z));
    const o = state.machine === 'comau' ? vec(state.pdl.orient, 3) : [0, 180, 0];
    T.multiply(zyz(o[0], o[1], o[2]));
    res = machine.obj.solve(T, machine.seeds);
  }
  setBadge('reach', res.ok ? null : (machine.kind === 'delta'
    ? 'Nozzle position outside the WASP build volume (Ø400 × 1000 mm)'
    : `Out of reach: the ${MACHINES[state.machine]} cannot put the nozzle here (off by ${res.posErr.toFixed(0)} mm). Move the plate or the part.`));
  return res;
}

// ------------------------------------------------------------------------------ helpers
function vec(v, n) {
  const a = Array.isArray(v) ? v : String(v ?? '').split(/[,;\s]+/).filter(Boolean).map(Number);
  return [...Array(n)].map((_, i) => Number.isFinite(+a[i]) ? +a[i] : 0);
}
const fmtVec = v => v.map(x => +(+x).toFixed(4)).join(', ');
function log(lines, open = false) {
  const el = $('logText');
  const t = new Date().toLocaleTimeString();
  el.textContent += (el.textContent ? '\n' : '') + [].concat(lines).map(l => `[${t}] ${l}`).join('\n');
  el.scrollTop = el.scrollHeight;
  if (open) $('logBox').classList.add('open');
  else if (!$('logBox').classList.contains('open')) $('logBox').classList.add('unread');
}
const badges = {};
function setBadge(key, text, ok = false) {
  if (!text) { if (badges[key]) { badges[key].remove(); delete badges[key]; } return; }
  if (!badges[key]) { badges[key] = document.createElement('div'); $('badges').append(badges[key]); }
  badges[key].className = 'badge' + (ok ? ' ok' : '');
  badges[key].textContent = text;
}
async function api(path, body) {
  const r = await fetch(path, body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : {});
  return r.json();
}
const desktop = () => !!(window.pywebview && window.pywebview.api);
const fmtTime = s => { s = Math.max(0, Math.round(s)); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0'); };

// number fields must not change when the wheel scrolls the panel over them
document.addEventListener('wheel', e => {
  const t = e.target;
  if (t instanceof HTMLInputElement && t.type === 'number' && document.activeElement === t) t.blur();
}, { capture: true, passive: true });

// ------------------------------------------------------------------------------ settings UI
const P_FIELDS = ['nozzle', 'layer_height', 'first_layer_height', 'print_speed', 'travel_speed'];
const PDL_NUM = ['print_speed_mm_s', 'travel_speed_mm_s', 'flow_rate_S', 'extrusion_factor', 'first_layer_z', 'approach_mm', 'retract_mm', 'approach_speed'];
const PDL_VEC = { tool: 6, uframe: 6, home: 6, orient: 3 };
const PDL_TXT = ['placement', 'config'];

function defaultParams(m) {
  const d = CONFIG.toolpaths[state.toolpath] || CONFIG.toolpaths.N2;
  const wasp = m === 'wasp';
  return {
    nozzle: d.INFILL_WIDTH, layer_height: d.LAYER_HEIGHT, first_layer_height: d.FIRST_LAYER_HEIGHT,
    print_speed: wasp ? d.INFILL_SPEED : d.COMAU_PRINT_FEED / 60, travel_speed: wasp ? d.TRAVEL_SPEED : d.COMAU_TRAVEL_FEED / 60,
  };
}

function renderSettings() {
  document.querySelectorAll('#machineList button').forEach(b => b.classList.toggle('active', b.dataset.m === state.machine));
  document.querySelectorAll('#toolpathSeg button').forEach(b => b.classList.toggle('active', b.dataset.t === state.toolpath));
  const imp = sliced && sliced.kind === 'gcode';
  $('toolpathSeg').classList.toggle('off', !!imp);
  $('importedBox').classList.toggle('hidden', !imp);
  if (imp) $('importedName').textContent = sliced.name;
  const d = CONFIG.toolpaths[state.toolpath];
  $('toolpathHint').textContent = imp
    ? 'The imported G-code is used as it is (coordinates = plate coordinates, mm). Slicing is not needed; Export writes it for the selected machine.'
    : `${state.toolpath}: sinusoidal weave infill with variable boundary (your Grasshopper ${state.toolpath} generator).`;
  $('paramsFor').textContent = MACHINES[state.machine];
  const p = state.params[state.machine];
  P_FIELDS.forEach(k => { $('p_' + k).value = p[k]; });
  const k = p.nozzle / d.INFILL_WIDTH;
  $('widthHint').textContent = `Bead widths follow the nozzle: outer wall ${(d.EXTERNAL_PERIMETER_WIDTH * k).toFixed(1)}, inner wall ${(d.PERIMETER_WIDTH * k).toFixed(1)}, weave ${(d.INFILL_WIDTH * k).toFixed(1)}, first layer ${(d.FIRST_LAYER_WIDTH * k).toFixed(1)} mm.`;
  ['Comau', 'Ur5', 'Wasp'].forEach(n => $('panel' + n).classList.toggle('hidden', n.toLowerCase() !== state.machine));
  PDL_NUM.forEach(k => { $('pdl_' + k).value = state.pdl[k] ?? ''; });
  PDL_TXT.forEach(k => { $('pdl_' + k).value = state.pdl[k] ?? ''; });
  Object.keys(PDL_VEC).forEach(k => { $('pdl_' + k).value = fmtVec(vec(state.pdl[k], PDL_VEC[k])); });
  const c = CONFIG.pdl;
  $('pdlFixed').textContent = `Fixed (settings.json): ${c.com_port} · gear ratio ${c.gear_ratio} · $FLY_DIST ${c.fly_dist} · $STRESS_PER ${c.stress_per}`;
  $('ur5_plate').value = fmtVec(vec(state.ur5.plate, 3));
  $('ur5_tcp').value = fmtVec(vec(state.ur5.tcp, 6));
  $('out_name').value = state.out_name;
  $('out_dir').value = state.out_dir;
  pdlStatus();
}

function pdlStatus() {
  const S = Math.round(+state.pdl.flow_rate_S * +state.pdl.extrusion_factor);
  const n = safeName(state.out_name || defaultName()), rb = { wasp: 'Wasp', ur5: 'UR5', comau: 'Comau' }[state.machine];
  $('pdlStatus').textContent = `S written: S${S} · program: ${pdlName()}.pdl`;
  $('outFiles').textContent = state.machine === 'comau' ? `→ ${n}${rb}.gcode + ${pdlName()}.pdl` : `→ ${n}${rb}.gcode`;
}
function pdlName() {                       // [file name][robot]: letters / digits only (PDL program name)
  const base = (safeName(state.out_name || defaultName()) + 'Comau').replace(/[^A-Za-z0-9]/g, '');
  return /^[A-Za-z]/.test(base) ? base : 'P' + base;
}
const safeName = s => (s || '').replace(/ /g, '_').replace(/[^A-Za-z0-9_\-]/g, '') || 'part';
const defaultName = () => (sliced && sliced.kind === 'gcode') ? sliced.name.replace(/\.[^.]+$/, '') : (objects[0] ? objects[0].name.replace(/\.[^.]+$/, '') : 'part');

let saveTimer = null;
function saveSettings() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => api('/api/settings', state).catch(() => {}), 500);
  commit();
}

// ------------------------------------------------------------------------------ undo / redo (Ctrl+Z, Ctrl+Y / Ctrl+X)
const hist = { past: [], future: [], last: null, restoring: false };
function snapshot() {
  return JSON.stringify({
    state, solo, sel: selected ? selected.id : null,
    objs: objects.map(o => ({ id: o.id, unit: o.unit, rot: o.rot, x: o.group.position.x, y: o.group.position.y, visible: o.visible })),
  });
}
function commit() {
  if (hist.restoring || !CONFIG) return;
  const s = snapshot();
  if (s === hist.last) return;
  if (hist.last) hist.past.push(hist.last);
  if (hist.past.length > 200) hist.past.shift();
  hist.future = [];
  hist.last = s;
  updateUndoButtons();
}
function undo() { if (!hist.past.length) return; hist.future.push(hist.last); hist.last = hist.past.pop(); restore(hist.last); }
function redo() { if (!hist.future.length) return; hist.past.push(hist.last); hist.last = hist.future.pop(); restore(hist.last); }
function updateUndoButtons() { $('btnUndo').disabled = !hist.past.length; $('btnRedo').disabled = !hist.future.length; }
const machineKey = () => JSON.stringify([state.machine, state.pdl.uframe, state.pdl.tool, state.pdl.home, state.ur5]);
function restore(snap) {
  hist.restoring = true;
  const d = JSON.parse(snap);
  const mk = machineKey();
  for (const k of Object.keys(d.state)) state[k] = d.state[k];
  solo = d.solo;
  tcontrols.detach();
  objects.forEach(o => objectsRoot.remove(o.group));
  objects.length = 0;
  for (const s of d.objs) {
    const o = registry.get(s.id);
    if (!o) continue;
    Object.assign(o, { unit: s.unit, rot: s.rot, visible: s.visible });
    o.group.position.set(s.x, s.y, 0);
    objectsRoot.add(o.group);
    objects.push(o);
    applyRotation(o);
  }
  selected = null;
  select(objects.find(o => o.id === d.sel) || null);
  renderSettings();
  if (mk !== machineKey()) buildMachine();
  placementChanged();
  applyObjectVisibility();
  if (sliced) updateLegend();
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => api('/api/settings', state).catch(() => {}), 500);
  hist.restoring = false;
  updateUndoButtons();
}

function parseVecInput(e, n) {
  const parts = e.target.value.split(/[,;\s]+/).filter(Boolean).map(Number);
  if (parts.length !== n || parts.some(x => !Number.isFinite(x))) { e.target.classList.add('bad'); return null; }
  e.target.classList.remove('bad');
  e.target.value = fmtVec(parts);
  return parts;
}

function bindSettings() {
  document.querySelectorAll('#machineList button').forEach(b => b.onclick = () => {
    if (state.machine === b.dataset.m) return;
    state.machine = b.dataset.m;
    animStop();
    renderSettings(); buildMachine().then(() => fitView('machine')); markStale(); saveSettings();
    if (sliced) updateLegend();
  });
  document.querySelectorAll('#toolpathSeg button').forEach(b => b.onclick = () => {
    if (sliced && sliced.kind === 'gcode') return;
    state.toolpath = b.dataset.t; renderSettings(); markStale(); saveSettings();
  });
  P_FIELDS.forEach(k => $('p_' + k).addEventListener('change', e => {
    const v = parseFloat(e.target.value);
    if (!(v > 0)) { e.target.value = state.params[state.machine][k]; return; }
    state.params[state.machine][k] = v;
    renderSettings();
    if (['nozzle', 'layer_height', 'first_layer_height'].includes(k)) markStale();
    if (sliced) { updateLegend(); anim.keys = null; }
    saveSettings();
  }));
  PDL_NUM.forEach(k => $('pdl_' + k).addEventListener('change', e => {
    const s = e.target.value.trim();
    if (s === '' && k.endsWith('_mm_s')) state.pdl[k] = '';
    else if (Number.isFinite(parseFloat(s))) state.pdl[k] = parseFloat(s);
    else e.target.value = state.pdl[k];
    pdlStatus(); saveSettings();
  }));
  PDL_TXT.forEach(k => $('pdl_' + k).addEventListener('change', e => { state.pdl[k] = e.target.value.trim(); pdlStatus(); saveSettings(); }));
  Object.entries(PDL_VEC).forEach(([k, n]) => $('pdl_' + k).addEventListener('change', e => {
    const v = parseVecInput(e, n);
    if (!v) return;
    state.pdl[k] = v;
    if (k !== 'home') buildMachine();
    saveSettings();
  }));
  [['ur5_plate', 'plate', 3], ['ur5_tcp', 'tcp', 6]].forEach(([id, k, n]) => $(id).addEventListener('change', e => {
    const v = parseVecInput(e, n);
    if (!v) return;
    state.ur5[k] = v; buildMachine(); saveSettings();
  }));
  $('out_name').addEventListener('change', e => { state.out_name = e.target.value.trim(); pdlStatus(); saveSettings(); });
  $('out_dir').addEventListener('change', e => { state.out_dir = e.target.value.trim(); saveSettings(); });
  $('btnOpenFolder').onclick = async () => { const r = await api('/api/open_folder', { path: state.out_dir }); if (!r.ok) log(r.error, true); };
  $('btnBrowse').onclick = async () => {
    const p = await window.pywebview.api.pick_folder(state.out_dir);
    if (p) { state.out_dir = p; $('out_dir').value = p; saveSettings(); }
  };
  const showBrowse = () => $('btnBrowse').classList.toggle('hidden', !desktop());
  showBrowse();
  window.addEventListener('pywebviewready', showBrowse);
}

// ------------------------------------------------------------------------------ objects
const clayMat = () => new THREE.MeshStandardMaterial({ color: 0xbfae9c, roughness: 0.85, metalness: 0.0 });

async function loadFiles(files) {
  for (const f of files) {
    const ext = f.name.split('.').pop().toLowerCase();
    try {
      let geom;
      if (ext === 'stl') geom = new STLLoader().parse(await f.arrayBuffer());
      else if (ext === 'obj') geom = groupToGeometry(new OBJLoader().parse(await f.text()));
      else if (ext === '3mf') geom = groupToGeometry(new ThreeMFLoader().parse(await f.arrayBuffer()));
      else if (/^(gcode|gco|nc)$/.test(ext)) { importGcode(f); continue; }
      else { log(`${f.name}: only STL, OBJ and 3MF can be added`, true); continue; }
      addObject(f.name, geom);
    } catch (e) {
      log(`${f.name}: could not be read (${e.message})`, true);
    }
  }
}

function groupToGeometry(group) {
  group.updateMatrixWorld(true);
  const parts = [];
  group.traverse(o => {
    if (!o.isMesh) return;
    const g = o.geometry.index ? o.geometry.toNonIndexed() : o.geometry.clone();
    const ng = new THREE.BufferGeometry();
    ng.setAttribute('position', g.getAttribute('position').clone());
    ng.applyMatrix4(o.matrixWorld);
    parts.push(ng);
  });
  if (!parts.length) throw new Error('no mesh found');
  return parts.length === 1 ? parts[0] : mergeGeometries(parts);
}

function addObject(name, geom) {
  geom.computeBoundingBox();
  const b = geom.boundingBox;
  geom.translate(-(b.min.x + b.max.x) / 2, -(b.min.y + b.max.y) / 2, -b.min.z);   // origin = centre of the lower face
  geom.deleteAttribute('normal');
  geom.computeVertexNormals();
  geom.computeBoundingBox();
  const mesh = new THREE.Mesh(geom, clayMat());
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  const group = new THREE.Group();      // position on the plate (x, y), scale = model units
  const pivot = new THREE.Group();      // rotation, moved so the rotated part stands on its lower-face centre
  const proxy = new THREE.Object3D();   // handle for the rotate gizmo (at the origin)
  pivot.add(mesh);
  group.add(pivot, proxy);
  objectsRoot.add(group);
  const o = { id: ++objId, name, group, pivot, proxy, mesh, unit: 1, rot: [0, 0, 0], size: [0, 0, 0], visible: true };
  registry.set(o.id, o);
  if (objects.length) {                 // several objects: next to each other
    const last = objects[objects.length - 1];
    group.position.x = last.group.position.x + last.size[0] / 2 + 40 + (b.max.x - b.min.x) / 2;
  }
  objects.push(o);
  applyRotation(o);
  select(o);
  placementChanged();
  if (objects.length === 1) fitView('plate');
  log(`Added ${name}: ${o.size.map(v => v.toFixed(1)).join(' × ')} mm`);
}

// rotation X, Y, Z (deg, applied X then Y then Z about the plate axes); the part is put back on the plate
function applyRotation(o, syncProxy = true) {
  const r = o.rot.map(v => v * D2R);
  o.pivot.position.set(0, 0, 0);
  o.pivot.rotation.set(r[0], r[1], r[2], 'ZYX');
  if (syncProxy) o.proxy.quaternion.copy(o.pivot.quaternion);
  o.pivot.updateMatrix();
  const R = o.pivot.matrix, p = o.mesh.geometry.attributes.position, v = new THREE.Vector3();
  let x0 = Infinity, y0 = Infinity, z0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (let i = 0; i < p.count; i++) {
    v.fromBufferAttribute(p, i).applyMatrix4(R);
    if (v.x < x0) x0 = v.x; if (v.x > x1) x1 = v.x;
    if (v.y < y0) y0 = v.y; if (v.y > y1) y1 = v.y;
    if (v.z < z0) z0 = v.z;
  }
  o.pivot.position.set(-(x0 + x1) / 2, -(y0 + y1) / 2, -z0);
  updateSize(o);
}

function updateSize(o) {
  plate.updateMatrixWorld(true);
  o.group.scale.setScalar(o.unit);
  o.group.updateMatrixWorld(true);
  const bb = new THREE.Box3().setFromObject(o.mesh, true);
  bb.applyMatrix4(new THREE.Matrix4().copy(plate.matrixWorld).invert());
  o.size = [bb.max.x - bb.min.x, bb.max.y - bb.min.y, bb.max.z - bb.min.z];
}

function renderObjectList() {
  const el = $('objectList');
  $('out_name').placeholder = defaultName();
  pdlStatus();
  if (!objects.length) { el.innerHTML = '<p class="empty">Drop STL / OBJ / 3MF files here or use <b>Add</b>.</p>'; $('objectProps').classList.add('hidden'); return; }
  el.innerHTML = '';
  for (const o of objects) {
    const d = document.createElement('div');
    d.className = 'obj' + (o === selected ? ' active' : '') + (isShown(o) ? '' : ' off');
    d.innerHTML = `<input type="checkbox" title="show / hide in the view and the preview" ${o.visible ? 'checked' : ''} ${solo ? 'disabled' : ''}><span class="nm"></span><span>${o.size.map(v => v.toFixed(0)).join(' × ')} mm</span>`;
    d.querySelector('.nm').textContent = o.name;
    const cb = d.querySelector('input');
    cb.onclick = e => e.stopPropagation();
    cb.onchange = () => { o.visible = cb.checked; applyObjectVisibility(); commit(); };
    d.onclick = () => select(o);
    el.append(d);
  }
  $('soloRow').classList.toggle('hidden', objects.length < 2);
  $('soloBox').checked = solo;
  $('objectProps').classList.toggle('hidden', !selected);
}

const isShown = o => solo ? o === selected : o.visible;
function applyObjectVisibility() {
  objects.forEach(o => { o.group.visible = isShown(o); });
  renderObjectList();
  if (sliced && sliced.kind === 'slice' && previewMesh) {
    const n = +$('layerSlider').value;
    buildPreview();
    $('layerSlider').value = n; setPreviewLayer(n);
  }
}

function select(o) {
  const prev = selected;
  selected = o;
  if (solo && prev !== o) { objects.forEach(x => { x.group.visible = isShown(x); }); if (sliced && sliced.kind === 'slice' && previewMesh) applyObjectVisibility(); }
  objects.forEach(x => x.mesh.material.emissive.setHex(x === o ? 0x062a3a : 0x000000));
  attachGizmo();
  renderObjectList();
  showObjectProps();
}
function attachGizmo() {
  if (selected && mode === 'prepare') tcontrols.attach(tcontrols.mode === 'rotate' ? selected.proxy : selected.group);
  else tcontrols.detach();
}

function showObjectProps() {
  if (!selected) return;
  const g = selected.group;
  $('o_x').value = g.position.x.toFixed(1);
  $('o_y').value = g.position.y.toFixed(1);
  $('o_unit').value = String(selected.unit);
  document.querySelectorAll('.rot').forEach(r => {
    const ax = +r.dataset.ax;
    const inp = r.querySelector('input');
    if (document.activeElement !== inp) inp.value = +selected.rot[ax].toFixed(2);
    r.classList.toggle('active', ax === rotAxis);
  });
  updateSize(selected);
  $('o_size').textContent = selected.size.map(v => v.toFixed(1)).join(' × ') + ' mm';
  renderPresets();
}

function renderPresets() {
  const el = $('rotPresets');
  const cur = selected ? selected.rot[rotAxis] : null;
  el.innerHTML = `<span class="lbl">${'XYZ'[rotAxis]} =</span>` + ROT_PRESETS.map(a => `<button data-a="${a}" class="${cur !== null && Math.abs(((cur % 360) + 360) % 360 - a) < 1e-6 ? 'on' : ''}">${a}°</button>`).join('');
  el.querySelectorAll('button').forEach(b => b.onclick = () => setRot(rotAxis, +b.dataset.a));
}

function setRot(ax, deg) {
  if (!selected) return;
  rotAxis = ax;
  let d = ((deg % 360) + 360) % 360;
  if (d > 180) d -= 360;                     // keep -180 … 180
  selected.rot[ax] = Math.round(d * 100) / 100;
  applyRotation(selected);
  showObjectProps();
  placementChanged();
}

function placementChanged() {
  objects.forEach(updateSize);
  renderObjectList();
  checkBounds();
  markStale();
  if (mode === 'prepare') poseMachine();
  commit();
}

function plateMatrixOf(o) {                  // mesh -> plate coordinates
  plate.updateMatrixWorld(true);
  o.mesh.updateWorldMatrix(true, false);
  return new THREE.Matrix4().copy(plate.matrixWorld).invert().multiply(o.mesh.matrixWorld);
}

function checkBounds() {
  let msg = null;
  if (state.machine === 'wasp') {
    for (const o of objects) {
      const p = o.mesh.geometry.attributes.position, v = new THREE.Vector3(), M = plateMatrixOf(o);
      let r = 0;
      const step = Math.max(1, Math.floor(p.count / 4000));
      for (let i = 0; i < p.count; i += step) { v.fromBufferAttribute(p, i).applyMatrix4(M); r = Math.max(r, Math.hypot(v.x, v.y)); }
      if (r > 200) msg = `${o.name} reaches ${r.toFixed(0)} mm from the bed centre (bed radius 200 mm)`;
      if (o.size[2] > 1000) msg = `${o.name} is taller than the 1000 mm build height`;
    }
  }
  setBadge('bed', msg);
}

function bindObjects() {
  $('btnAdd').onclick = () => $('fileInput').click();
  $('fileInput').onchange = e => { loadFiles([...e.target.files]); e.target.value = ''; };
  $('btnMove').onclick = () => setTMode('translate');
  $('btnRotate').onclick = () => setTMode('rotate');
  $('btnCenter').onclick = () => { if (!selected) return; selected.group.position.set(0, 0, 0); showObjectProps(); placementChanged(); };
  $('btnDelete').onclick = deleteSelected;
  [['o_x', v => selected.group.position.x = v], ['o_y', v => selected.group.position.y = v]].forEach(([id, f]) =>
    $(id).addEventListener('change', e => { if (!selected) return; const v = parseFloat(e.target.value); if (Number.isFinite(v)) f(v); showObjectProps(); placementChanged(); }));
  $('o_unit').addEventListener('change', e => { if (!selected) return; selected.unit = +e.target.value; showObjectProps(); placementChanged(); });
  // rotation rows: field, - / + by the step, presets for the active axis
  const step = () => +$('rotStep').value;
  document.querySelectorAll('.rot').forEach(r => {
    const ax = +r.dataset.ax, inp = r.querySelector('input');
    inp.addEventListener('focus', () => { rotAxis = ax; showObjectProps(); });
    inp.addEventListener('change', () => { const v = parseFloat(inp.value); if (Number.isFinite(v)) setRot(ax, v); });
    r.querySelectorAll('button').forEach(b => b.onclick = () => {
      if (!selected) return;
      const s = step(), cur = selected.rot[ax];
      const next = +b.dataset.d > 0 ? Math.floor(cur / s + 1e-6) * s + s : Math.ceil(cur / s - 1e-6) * s - s;   // to the next multiple of the step
      setRot(ax, next);
    });
    r.querySelector('.ax').onclick = () => { rotAxis = ax; showObjectProps(); };
  });
  $('rotStep').addEventListener('change', () => {
    document.querySelectorAll('.rot input').forEach(i => { i.step = $('rotStep').value; });
    tcontrols.setRotationSnap(step() * D2R);
  });
  $('btnRotReset').onclick = () => { if (!selected) return; selected.rot = [0, 0, 0]; applyRotation(selected); showObjectProps(); placementChanged(); };

  vp.addEventListener('dragover', e => { e.preventDefault(); vp.classList.add('drop'); });
  vp.addEventListener('dragleave', () => vp.classList.remove('drop'));
  vp.addEventListener('drop', e => { e.preventDefault(); vp.classList.remove('drop'); loadFiles([...e.dataTransfer.files]); });
  $('side').addEventListener('dragover', e => e.preventDefault());
  $('side').addEventListener('drop', e => { e.preventDefault(); loadFiles([...e.dataTransfer.files]); });

  let down = null;
  renderer.domElement.addEventListener('pointerdown', e => { down = [e.clientX, e.clientY]; });
  renderer.domElement.addEventListener('pointerup', e => {
    if (!down || Math.hypot(e.clientX - down[0], e.clientY - down[1]) > 4 || mode !== 'prepare' || tcontrols.dragging) return;
    const r = renderer.domElement.getBoundingClientRect();
    const ray = new THREE.Raycaster();
    ray.setFromCamera(new THREE.Vector2((e.clientX - r.left) / r.width * 2 - 1, -(e.clientY - r.top) / r.height * 2 + 1), camera);
    const hit = ray.intersectObjects(objects.map(o => o.mesh))[0];
    select(hit ? objects.find(o => o.mesh === hit.object) : null);
  });
  window.addEventListener('keydown', e => {
    if (/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName)) return;
    if (e.ctrlKey || e.metaKey) {
      const k = e.key.toLowerCase();
      if (k === 'z' && !e.shiftKey) { undo(); e.preventDefault(); return; }
      if (k === 'y' || k === 'x' || (k === 'z' && e.shiftKey)) { redo(); e.preventDefault(); return; }
    }
    if (mode === 'prepare') {
      if (e.key === 'Delete' || e.key === 'Backspace') deleteSelected();
      if (e.key === 'w') setTMode('translate');
      if (e.key === 'e') setTMode('rotate');
    } else if (sliced) {
      const s = $('layerSlider');
      if (e.key === ' ') { animToggle(); e.preventDefault(); }
      if (e.key === 'ArrowUp') { animStop(); s.value = Math.min(+s.max, +s.value + 1); setPreviewLayer(+s.value); e.preventDefault(); }
      if (e.key === 'ArrowDown') { animStop(); s.value = Math.max(1, +s.value - 1); setPreviewLayer(+s.value); e.preventDefault(); }
    }
  });
}

function setTMode(m) {
  tcontrols.setMode(m);
  tcontrols.showX = tcontrols.showY = true;
  tcontrols.showZ = m === 'rotate';
  tcontrols.setRotationSnap(m === 'rotate' ? +$('rotStep').value * D2R : null);
  $('btnMove').classList.toggle('active', m === 'translate');
  $('btnRotate').classList.toggle('active', m === 'rotate');
  attachGizmo();
}

function deleteSelected() {
  if (!selected) return;
  tcontrols.detach();
  objectsRoot.remove(selected.group);
  selected.mesh.geometry.dispose();
  objects.splice(objects.indexOf(selected), 1);
  selected = null;
  select(objects[objects.length - 1] || null);
  placementChanged();
}

// ------------------------------------------------------------------------------ STL export
function objectSTL(o) {
  const g = o.mesh.geometry.index ? o.mesh.geometry.toNonIndexed() : o.mesh.geometry;
  const p = g.attributes.position;
  const n = p.count / 3;
  const buf = new ArrayBuffer(84 + n * 50);
  const dv = new DataView(buf);
  dv.setUint32(80, n, true);
  const a = new THREE.Vector3(), b = new THREE.Vector3(), c = new THREE.Vector3(), nn = new THREE.Vector3(), t = new THREE.Vector3();
  const M = plateMatrixOf(o);
  const flip = M.determinant() < 0;
  let off = 84;
  for (let i = 0; i < n; i++) {
    a.fromBufferAttribute(p, 3 * i).applyMatrix4(M);
    b.fromBufferAttribute(p, 3 * i + 1).applyMatrix4(M);
    c.fromBufferAttribute(p, 3 * i + 2).applyMatrix4(M);
    if (flip) { t.copy(b); b.copy(c); c.copy(t); }
    nn.subVectors(c, b).cross(t.subVectors(a, b)).normalize();
    for (const v of [nn, a, b, c]) { dv.setFloat32(off, v.x, true); dv.setFloat32(off + 4, v.y, true); dv.setFloat32(off + 8, v.z, true); off += 12; }
    off += 2;
  }
  const bytes = new Uint8Array(buf);
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}

// ------------------------------------------------------------------------------ slicing
let busyTimer = null;
function busy(on, text) {
  $('busy').classList.toggle('hidden', !on);
  clearInterval(busyTimer);
  if (on) {
    const t0 = Date.now();
    const upd = () => { $('busyText').textContent = `${text}  ${((Date.now() - t0) / 1000).toFixed(0)} s`; };
    upd(); busyTimer = setInterval(upd, 500);
  }
}

async function slicePlate() {
  if (!objects.length) { log('Add an object to the plate first.', true); return; }
  const p = state.params[state.machine];
  const sig = sliceSignature();
  animStop();
  busy(true, `Slicing ${objects.length} object${objects.length > 1 ? 's' : ''} with ${state.toolpath}…`);
  $('exportCard').classList.add('hidden');
  try {
    const r = await api('/api/slice', {
      toolpath: state.toolpath,
      objects: objects.map(o => ({ name: o.name, stl: objectSTL(o) })),
      params: { nozzle: p.nozzle, layer_height: p.layer_height, first_layer_height: p.first_layer_height },
    });
    if (r.log) log(r.log);
    if (!r.ok) { log(`Slicing failed: ${r.error}`, true); return; }
    log(`Sliced with ${state.toolpath} in ${r.seconds} s: ${r.toolpaths.layers.length} layers`);
    sliced = { kind: 'slice', slice_id: r.slice_id, layers: r.toolpaths.layers, toolpath: state.toolpath, signature: sig, objIds: objects.map(o => o.id) };
    stale = false;
    setBadge('stale', null);
    buildPreview();
    setMode('preview');
    $('btnExport').disabled = false;
  } catch (e) {
    log(`Slicing failed: ${e.message}`, true);
  } finally {
    busy(false);
  }
}

function sliceSignature() {
  const p = state.params[state.machine];
  return JSON.stringify([state.toolpath, p.nozzle, p.layer_height, p.first_layer_height,
    objects.map(o => [o.id, o.unit, o.rot.join(','), o.group.position.x.toFixed(2), o.group.position.y.toFixed(2)])]);
}
function markStale() {
  if (!sliced || sliced.kind !== 'slice') return;
  stale = sliceSignature() !== sliced.signature;
  setBadge('stale', stale ? 'Plate or slicing settings changed since slicing: slice again before exporting.' : null);
}

// ------------------------------------------------------------------------------ preview
let previewMesh = null, layerEnds = [], layerLast = [], segs = [], segLayer = [];
const hidden = new Set();

function rdp(pts, tol) {
  if (pts.length < 3) return pts;
  const [fx, fy] = pts[0], [lx, ly] = pts[pts.length - 1];
  if (Math.hypot(lx - fx, ly - fy) < 1e-6) {          // closed loop: split at the point farthest from the start
    let far = 1, fd = -1;
    for (let i = 1; i < pts.length - 1; i++) { const d = Math.hypot(pts[i][0] - fx, pts[i][1] - fy); if (d > fd) { fd = d; far = i; } }
    if (fd <= 0) return [pts[0]];
    return [...rdp(pts.slice(0, far + 1), tol).slice(0, -1), ...rdp(pts.slice(far), tol)];
  }
  const keep = new Uint8Array(pts.length); keep[0] = keep[pts.length - 1] = 1;
  const stack = [[0, pts.length - 1]];
  while (stack.length) {
    const [a, b] = stack.pop();
    const [ax, ay] = pts[a], [bx, by] = pts[b];
    const dx = bx - ax, dy = by - ay, L = Math.hypot(dx, dy) || 1e-9;
    let md = 0, mi = -1;
    for (let i = a + 1; i < b; i++) {
      const d = Math.abs((pts[i][0] - ax) * dy - (pts[i][1] - ay) * dx) / L;
      if (d > md) { md = d; mi = i; }
    }
    if (md > tol) { keep[mi] = 1; stack.push([a, mi], [mi, b]); }
  }
  return pts.filter((_, i) => keep[i]);
}

const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _s = new THREE.Vector3(), _p = new THREE.Vector3(), _z = new THREE.Vector3(0, 0, 1);
function segMatrix(i, f = 1) {               // bead i, the first fraction f of it
  const [x0, y0, x1, y1, zc, w, h, , l] = segs[i];
  const xe = x0 + (x1 - x0) * f, ye = y0 + (y1 - y0) * f;
  _p.set((x0 + xe) / 2, (y0 + ye) / 2, zc);
  _q.setFromAxisAngle(_z, Math.atan2(y1 - y0, x1 - x0));
  _s.set(l * f + w * 0.35 * Math.min(1, f * 4), w, h);
  return _m.compose(_p, _q, _s);
}

function buildPreview() {
  animReset();
  previewRoot.clear();
  if (previewMesh) { previewMesh.geometry.dispose(); previewMesh.material.dispose(); previewMesh = null; }
  const layers = sliced.layers;
  segs = []; segLayer = []; layerEnds = []; layerLast = [];
  let len = 0;
  const nozzle = state.params[state.machine].nozzle;
  layers.forEach((L, li) => {
    const zc = L.z - L.height / 2;
    let last = null;
    for (const p of L.paths) {
      const type = TYPE_STYLE[p.type] ? p.type : 'other';
      if (hidden.has(type)) continue;
      if (sliced.objIds && p.obj != null) {             // hidden object -> its toolpath is hidden too
        const o = registry.get(sliced.objIds[p.obj]);
        if (o && (!objects.includes(o) || !isShown(o))) continue;
      }
      let pts = rdp(p.pts, 0.2);
      if (p.closed && pts.length > 2) pts = [...pts, pts[0]];
      const w = p.width || nozzle;
      for (let i = 1; i < pts.length; i++) {
        const [x0, y0] = pts[i - 1], [x1, y1] = pts[i];
        const l = Math.hypot(x1 - x0, y1 - y0);
        if (l < 1e-6) continue;
        segs.push([x0, y0, x1, y1, zc, w, L.height, type, l, L.z]);
        segLayer.push(li);
        len += l;
      }
      if (pts.length) last = pts[pts.length - 1];
    }
    layerEnds[li] = segs.length;
    layerLast[li] = last ? new THREE.Vector3(last[0], last[1], L.z) : (layerLast[li - 1] || new THREE.Vector3(0, 0, L.z));
  });
  sliced.length = len; sliced.segments = segs.length;
  const geo = new THREE.CylinderGeometry(0.5, 0.5, 1, 6, 1, true);   // bead: 6-sided prism along x
  geo.rotateZ(Math.PI / 2);
  const mat = new THREE.MeshStandardMaterial({ roughness: 0.6, metalness: 0.0 });
  const mesh = new THREE.InstancedMesh(geo, mat, Math.max(1, segs.length));
  const col = new THREE.Color();
  segs.forEach((s, i) => { mesh.setMatrixAt(i, segMatrix(i)); mesh.setColorAt(i, col.setHex(TYPE_STYLE[s[7]].color)); });
  mesh.instanceMatrix.needsUpdate = true;
  if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  mesh.frustumCulled = false;
  previewMesh = mesh;
  previewRoot.add(mesh);
  const sl = $('layerSlider');
  sl.max = layers.length;
  sl.value = layers.length;
  setPreviewLayer(layers.length);
  updateLegend();
}

function setPreviewLayer(n) {
  if (!sliced || !previewMesh) return;
  restorePartial();
  n = Math.max(1, Math.min(n, sliced.layers.length));
  previewMesh.count = layerEnds[n - 1] || 0;
  showLayerLabel(n);
  if (mode === 'preview') poseMachine(layerLast[n - 1]);
}
function showLayerLabel(n) {
  const L = sliced.layers[n - 1];
  $('layerNow').textContent = `${n} / ${sliced.layers.length}`;
  $('layerZ').textContent = `${L.z.toFixed(1)} mm`;
}

function updateLegend() {
  if (!sliced) return;
  const el = $('legend');
  const p = state.params[state.machine];
  const types = [...new Set(sliced.layers.flatMap(L => L.paths.map(q => TYPE_STYLE[q.type] ? q.type : 'other')))];
  const t = sliced.length / p.print_speed;
  el.innerHTML = types.map(k => `<div class="row${hidden.has(k) ? ' off' : ''}" data-k="${k}"><span class="sw" style="background:#${TYPE_STYLE[k].color.toString(16).padStart(6, '0')}"></span>${TYPE_STYLE[k].label}</div>`).join('') +
    `<div class="stats"><span>Source</span><span>${sliced.kind === 'gcode' ? 'imported G-code' : sliced.toolpath}</span>` +
    `<span>Layers</span><span>${sliced.layers.length}</span>` +
    `<span>Height</span><span>${sliced.layers[sliced.layers.length - 1].z.toFixed(1)} mm</span>` +
    `<span>Path</span><span>${(sliced.length / 1000).toFixed(1)} m</span>` +
    `<span>Print time</span><span>≈ ${fmtTime(t)} at ${p.print_speed} mm/s</span></div>` +
    `<div class="ctl"><label><input type="checkbox" id="showModel" ${showModel ? 'checked' : ''}> Show model</label>` +
    `<div class="mview"><span>Machine</span>${['solid', 'ghost', 'hidden'].map(v => `<button data-v="${v}" class="${machineView === v ? 'on' : ''}">${{ solid: 'Solid', ghost: 'Transparent', hidden: 'Off' }[v]}</button>`).join('')}</div></div>`;
  el.querySelectorAll('.row').forEach(r => r.onclick = () => {
    const k = r.dataset.k;
    hidden.has(k) ? hidden.delete(k) : hidden.add(k);
    buildPreview();
  });
  $('showModel').onchange = e => { showModel = e.target.checked; applyModeVisibility(); };
  el.querySelectorAll('.mview button').forEach(b => b.onclick = () => { machineView = b.dataset.v; applyMachineView(); updateLegend(); });
}
let showModel = false;

function applyModeVisibility() {
  applyMachineView();
  const prev = mode === 'preview' && sliced;
  previewRoot.visible = !!prev;
  objectsRoot.visible = !prev || showModel;
  objects.forEach(o => {
    o.mesh.material.transparent = !!prev;
    o.mesh.material.opacity = prev ? 0.18 : 1;
    o.mesh.material.depthWrite = !prev;
  });
}

function setMode(m) {
  mode = m;
  if (m !== 'preview') animStop();
  $('tabPrepare').classList.toggle('active', m === 'prepare');
  $('tabPreview').classList.toggle('active', m === 'preview');
  $('toolbar').classList.toggle('preview', m === 'preview');
  const show = m === 'preview' && !!sliced;
  ['layerbar', 'legend', 'player'].forEach(id => $(id).classList.toggle('hidden', !show));
  if (m === 'preview') {
    tcontrols.detach();
    if (sliced) { if (anim.t > 0) animRender(); else setPreviewLayer(+$('layerSlider').value); }
    else setBadge('nothing', 'Nothing sliced yet: press Slice plate.');
  } else { setBadge('nothing', null); attachGizmo(); poseMachine(); }
  applyModeVisibility();
}

// ------------------------------------------------------------------------------ playback (robot follows the toolpath)
const anim = { playing: false, t: 0, keys: null, total: 0, partial: -1, last: 0 };

function buildTimeline() {
  const p = state.params[state.machine];
  const ps = p.print_speed, ts = p.travel_speed, lift = 10;
  const keys = [];
  let t = 0, prev = null;
  const key = (x, y, z, done) => keys.push({ t, x, y, z, done });
  segs.forEach((s, i) => {
    const [x0, y0, x1, y1, , , , , l, z] = s;
    if (!prev) key(x0, y0, z + lift, 0);
    else {
      const d = Math.hypot(x0 - prev[0], y0 - prev[1]);
      if (d > 0.05 || Math.abs(z - prev[2]) > 0.01) {
        if (d < 3 && Math.abs(z - prev[2]) < 0.01) { t += d / ts; }              // short hop: no lift
        else {
          const top = Math.max(z, prev[2]) + lift;
          t += (top - prev[2]) / ts; key(prev[0], prev[1], top, i);
          t += d / ts; key(x0, y0, top, i);
          t += (top - z) / ts;
        }
      }
    }
    key(x0, y0, z, i);
    t += l / ps;
    key(x1, y1, z, i + 1);
    prev = [x1, y1, z];
  });
  anim.keys = keys;
  anim.total = t;
}

function restorePartial() {
  if (anim.partial >= 0 && previewMesh) {
    previewMesh.setMatrixAt(anim.partial, segMatrix(anim.partial));
    previewMesh.instanceMatrix.needsUpdate = true;
  }
  anim.partial = -1;
}

const _pt = new THREE.Vector3();
function animRender() {
  if (!sliced || !previewMesh) return;
  if (!anim.keys) buildTimeline();
  const K = anim.keys;
  if (!K.length) return;
  const t = Math.min(Math.max(anim.t, 0), anim.total);
  let lo = 0, hi = K.length - 1;
  while (hi - lo > 1) { const mid = (lo + hi) >> 1; if (K[mid].t <= t) lo = mid; else hi = mid; }
  const a = K[lo], b = K[Math.min(lo + 1, K.length - 1)];
  const f = b.t > a.t ? (t - a.t) / (b.t - a.t) : 1;
  _pt.set(a.x + (b.x - a.x) * f, a.y + (b.y - a.y) * f, a.z + (b.z - a.z) * f);
  restorePartial();
  let count = a.done;
  if (b.done > a.done && f > 0 && f < 1) {   // bead being printed: show the part already laid down
    previewMesh.setMatrixAt(a.done, segMatrix(a.done, f));
    previewMesh.instanceMatrix.needsUpdate = true;
    anim.partial = a.done;
    count = a.done + 1;
  } else if (b.done > a.done && f >= 1) count = b.done;
  previewMesh.count = count;
  const li = segLayer[Math.max(0, Math.min(count, segs.length) - 1)] ?? 0;
  $('layerSlider').value = li + 1;
  showLayerLabel(li + 1);
  poseMachine(_pt);
  $('animScrub').value = Math.round(t / anim.total * 1000);
  $('animTime').textContent = `${fmtTime(t)} / ${fmtTime(anim.total)}`;
}

function animToggle() {
  if (!sliced) return;
  if (!anim.keys) buildTimeline();
  if (anim.playing) { animStop(); return; }
  if (anim.t >= anim.total) anim.t = 0;
  anim.playing = true;
  anim.last = performance.now();
  $('animPlay').textContent = '❚❚';
}
function animStop() {
  anim.playing = false;
  $('animPlay').textContent = '▶';
}
function animReset() {
  animStop();
  anim.t = 0; anim.keys = null; anim.partial = -1;
  $('animScrub').value = 0;
  $('animTime').textContent = '0:00 / 0:00';
}
function animTick(now) {
  if (!anim.playing) return;
  const dt = Math.min(0.1, (now - anim.last) / 1000);
  anim.last = now;
  anim.t += dt * +$('animSpeed').value;
  if (anim.t >= anim.total) { anim.t = anim.total; animStop(); }
  animRender();
}

function bindPlayer() {
  $('animPlay').onclick = animToggle;
  $('animRestart').onclick = () => { anim.t = 0; animRender(); };
  $('animScrub').addEventListener('input', e => {
    if (!anim.keys) buildTimeline();
    anim.t = +e.target.value / 1000 * anim.total;
    animRender();
  });
  $('layerSlider').addEventListener('input', e => { animStop(); anim.t = 0; setPreviewLayer(+e.target.value); });
}

// ------------------------------------------------------------------------------ import G-code
async function importGcode(file) {
  const text = await file.text();
  const parsed = parseGcode(text);
  if (!parsed.layers.length) { log(`${file.name}: no extruding moves found`, true); return; }
  sliced = { kind: 'gcode', name: file.name, text, layers: parsed.layers };
  stale = false;
  setBadge('stale', null);
  log(`Imported ${file.name}: ${parsed.layers.length} layers, ${parsed.moves} extruding moves${parsed.notes.length ? ' · ' + parsed.notes.join(' · ') : ''}`);
  renderSettings();
  renderObjectList();
  buildPreview();
  setMode('preview');
  fitView('plate');
  $('btnExport').disabled = false;
}

// ------------------------------------------------------------------------------ export
async function exportFiles() {
  if (!sliced) return;
  if (stale && sliced.kind === 'slice') { log('Slice again first: the plate or the settings changed.', true); return; }
  const p = state.params[state.machine];
  const name = state.out_name || defaultName();
  busy(true, `Writing ${state.machine === 'comau' ? 'G-code + PDL' : 'G-code'} for ${MACHINES[state.machine]}…`);
  try {
    const pdl = Object.fromEntries(PDL_EDITABLE.map(k => [k, state.pdl[k]]));
    const body = { machine: state.machine, name, params: p, pdl, out_dir: state.out_dir };
    if (sliced.kind === 'gcode') body.gcode_text = sliced.text; else body.slice_id = sliced.slice_id;
    const r = await api('/api/export', body);
    if (r.log) log(r.log);
    const card = $('exportCard');
    card.classList.remove('hidden');
    if (!r.ok) {
      card.innerHTML = `<h4>Export failed</h4><div class="err"></div><div class="row"><button class="btn small" id="ecClose">Close</button></div>`;
      card.querySelector('.err').textContent = r.error;
      log(`Export failed: ${r.error}`, true);
    } else {
      const sum = (r.log || []).filter(l => /^(Weight|weight:|PDL:|Print time|layers:)/.test(l.trim())).slice(0, 4).join('\n');
      card.innerHTML = `<h4>Saved for ${MACHINES[state.machine]}</h4>` +
        r.files.map(f => `<div class="f"><code></code><span><a href="#" data-reveal="${encodeURIComponent(f.path)}">Show</a>${desktop() ? '' : ` · <a href="/api/file?path=${encodeURIComponent(f.path)}">Download</a>`}</span></div>`).join('') +
        `<p class="sum"></p><div class="row"><button class="btn small" id="ecOpen">Open folder</button><button class="btn small" id="ecClose">Close</button></div>`;
      card.querySelectorAll('code').forEach((c, i) => { c.textContent = `${r.files[i].name}  (${(r.files[i].size / 1024).toFixed(0)} kB)`; });
      card.querySelector('.sum').textContent = `${r.out_dir}\n${sum}`;
      $('ecOpen').onclick = () => api('/api/open_folder', { path: r.out_dir });
      card.querySelectorAll('[data-reveal]').forEach(a => a.onclick = e => { e.preventDefault(); api('/api/reveal', { path: decodeURIComponent(a.dataset.reveal) }); });
      log(`Saved ${r.files.map(f => f.name).join(', ')} in ${r.out_dir}`);
    }
    $('ecClose').onclick = () => card.classList.add('hidden');
  } catch (e) {
    log(`Export failed: ${e.message}`, true);
  } finally {
    busy(false);
  }
}

// ------------------------------------------------------------------------------ camera
function fitView(kind) {
  const pw = new THREE.Vector3().setFromMatrixPosition(plate.matrix);
  let h = 300;
  for (const o of objects) h = Math.max(h, o.size[2]);
  let target, dist, dir;
  if (kind === 'machine' || kind === 'iso') {
    const box = new THREE.Box3().setFromObject(machineRoot).expandByPoint(pw);
    box.min.z = Math.max(box.min.z, pw.z - 300);         // ignore the table legs / printer base below the plate
    target = box.getCenter(new THREE.Vector3());
    dist = box.getSize(new THREE.Vector3()).length() * (kind === 'iso' ? 1.35 : 1.3);
    dir = kind === 'iso' ? new THREE.Vector3(1, -1, 0.8) : new THREE.Vector3(0.9, -1.25, 0.7);
  } else if (kind === 'top') { target = pw.clone(); dir = new THREE.Vector3(0, -0.001, 1); dist = Math.max(1100, h * 5); }
  else if (kind === 'front') { target = pw.clone().add(new THREE.Vector3(0, 0, h / 2)); dir = new THREE.Vector3(0, -1, 0.12); dist = Math.max(1100, h * 5); }
  else { target = pw.clone().add(new THREE.Vector3(0, 0, h / 2)); dist = Math.max(900, h * 4.2); dir = new THREE.Vector3(0.75, -1.1, 0.85); }
  orbit.target.copy(target);
  camera.position.copy(target).add(dir.normalize().multiplyScalar(dist));
  orbit.update();
}

// ------------------------------------------------------------------------------ main
function resize() {
  const r = vp.getBoundingClientRect();
  renderer.setSize(r.width, r.height);
  camera.aspect = r.width / r.height;
  camera.updateProjectionMatrix();
}
new ResizeObserver(resize).observe(vp);

function animate(now) {
  requestAnimationFrame(animate);
  animTick(now);
  orbit.update();
  renderer.render(scene, camera);
}

function splash(text, done = false) {        // loading screen (in index.html) until the app is ready
  const el = document.getElementById('splash');
  if (!el) return;
  el.querySelector('.st').textContent = text;
  if (done) { el.classList.add('done'); setTimeout(() => el.remove(), 600); }
}

async function init() {
  splash('Starting the slicer engine');
  CONFIG = await api('/api/config');
  state.pdl = { ...CONFIG.pdl, placement: 'keep' };
  for (const m of Object.keys(MACHINES)) state.params[m] = defaultParams(m);
  state.out_dir = CONFIG.out_dir;
  state.ur5.tcp = [-495.07, 0.01, -40.33, 0, -93.35, 0];     // TCP of the station extruder (ur5_station model)
  splash('Loading settings');
  const saved = CONFIG.saved;
  if (saved) {
    for (const k of ['machine', 'toolpath', 'out_name', 'out_dir']) if (saved[k] != null) state[k] = saved[k];
    if (saved.pdl) for (const k of PDL_EDITABLE) if (saved.pdl[k] != null) state.pdl[k] = saved.pdl[k];
    if (saved.params) for (const m of Object.keys(MACHINES)) Object.assign(state.params[m], saved.params[m] || {});
    if (saved.ur5 && saved.v === SETTINGS_VERSION) Object.assign(state.ur5, saved.ur5);   // older versions had a placeholder tool
  }
  bindSettings();
  bindObjects();
  bindPlayer();
  renderSettings();
  setTMode('translate');
  resize();
  splash(`Loading the ${MACHINES[state.machine]} model`);
  await buildMachine();
  fitView('machine');
  requestAnimationFrame(animate);
  splash('Ready', true);

  $('tabPrepare').onclick = () => setMode('prepare');
  $('tabPreview').onclick = () => setMode('preview');
  $('btnSlice').onclick = slicePlate;
  $('btnExport').onclick = exportFiles;
  $('btnImportGcode').onclick = () => $('gcodeInput').click();
  $('gcodeInput').onchange = e => { if (e.target.files[0]) importGcode(e.target.files[0]); e.target.value = ''; };
  $('btnClearImport').onclick = () => {
    animReset();
    sliced = null; previewRoot.clear(); previewMesh = null; $('btnExport').disabled = true;
    renderSettings(); setMode('prepare'); log('Imported G-code removed');
  };
  document.querySelectorAll('[data-view]').forEach(b => b.onclick = () => fitView(b.dataset.view));
  $('logToggle').onclick = () => { $('logBox').classList.toggle('open'); $('logBox').classList.remove('unread'); };
  $('btnUndo').onclick = undo;
  $('btnRedo').onclick = redo;
  $('soloBox').onchange = e => { solo = e.target.checked; applyObjectVisibility(); commit(); };
  hist.last = snapshot();
  updateUndoButtons();
  log('LAMA Slicer ready. Add a part (STL / OBJ / 3MF), pick the machine and toolpath, then Slice plate.');
  window.LAMA = { state, objects, undo, redo, get solo() { return solo; }, loadFiles, slicePlate, exportFiles, setMode, fitView, importGcode, setPreviewLayer, setRot, anim, animRender, animToggle, get sliced() { return sliced; } };
}
init().catch(e => {
  const el = document.getElementById('splash');
  if (el) { el.classList.add('err'); el.querySelector('.ld').textContent = 'Could not start'; el.querySelector('.st').textContent = e.message; }
  console.error(e);
});
