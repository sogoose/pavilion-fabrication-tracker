@echo off
title LAMA Slicer (browser mode)
cd /d "%~dp0"
where py >nul 2>nul && (set "PY=py -3") || (set "PY=python")
rem Fallback: runs LAMA Slicer in the web browser instead of its own window.
%PY% lama_server.py
pause
